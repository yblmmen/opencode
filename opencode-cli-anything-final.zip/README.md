# OpenCode + CLI-Anything + Hubble Dashboard (Kubernetes)

**서버:** `master1` · **경로:** `/opt/opencode` · **네임스페이스:** `opencode` · **GitHub:** `yblmmen/opencode` (`main`)

**목표:** Docker Compose 대신 Kubernetes에서 OpenCode 2.0.7과 CLI-Anything을 실행하고, 기존 Cilium Hubble 흐름을 대시보드/Draw.io로 표시한다.

## 구성도

![구성도](docs/architecture.svg)

- OpenCode: Kubernetes Pod 안에서 터미널 실행, CLI-Anything 슬래시 명령어 5종.
- Hubble: **기존 Hubble Relay 데이터**를 수집한다. `hubble.innerinfo.org`는 기존 웹 UI이며 Relay API URL이라고 가정하지 않는다.
- Dashboard: 흐름 이벤트 통계 표시, `.drawio` 스냅샷 내보내기. Hubble의 Flow 이벤트 ≠ 실제 동시 TLS 세션 수.

## 처음 설치 (master1에서 root로 실행)

> 필수: `git`, `docker`, `kubectl`, `ctr`(containerd), `openssl`, `unzip`, Kubernetes node `master1`.
> 기존 Docker 컨테이너는 Kubernetes 배포 전에 중지. 기존 설치가 있다면 백업 후 진행.

**1. GitHub 저장소 받아오기** (이미 `.git`이 있는 `/opt/opencode`라면 Clone 생략)

```bash
git config --global credential.helper store
git clone https://github.com/yblmmen/opencode.git /opt/opencode
cd /opt/opencode
```

**2. 이 ZIP을 `/opt/opencode`에 풀기**

```bash
cd /opt/opencode
unzip -o /root/opencode-cli-anything-final.zip -d /opt/opencode
```

**3. 설치 (한 번)**

```bash
cd /opt/opencode
bash scripts/install.sh
```

- `secrets/ollama_api_key`가 없으면 **Ollama API 키**를 한 번 질문한다 (GitHub 토큰 아님).
- 기존 `config/opencode.json`이 있다면 그대로 사용한다. 새 환경에 모델 설정이 없다면 OpenCode 내 `/connect`에서 설정한다.
- 이미지 2개를 Docker로 빌드하고 `master1`의 containerd로 가져온다.

**4. 실행**

```bash
kubectl -n opencode get pods
kubectl -n opencode exec -it deploy/opencode -- opencode
```

OpenCode 창에서 `/cli-anything-list`를 입력해 명령 인식을 확인한다. CLI-Anything은 *임의의 프로그램 소스를 CLI로 만드는 도구*이다.

**5. 대시보드** (별도 터미널)

```bash
kubectl -n opencode port-forward svc/https-dashboard 18080:8080
```

브라우저: `http://127.0.0.1:18080` (다른 PC에서는 SSH 포트포워딩 필요). 화면에서 Draw.io 내보내기를 사용할 수 있다. Hubble을 연결하기 전에는 실제 이벤트가 없다.

## Hubble 실시간 데이터 연동 (선택 · 운영 중인 Relay는 변경하지 않음)

1. 서비스 조회: `kubectl get svc -A | grep hubble-relay`
2. Relay가 `kube-system` 네임스페이스의 포트 80이면, **터미널 A**:

```bash
kubectl -n kube-system port-forward svc/hubble-relay 4245:80
```

3. **터미널 B:** Hubble CLI가 설치되어 있고 대시보드 포트포워딩도 실행 중이라면:

```bash
cd /opt/opencode
hubble observe --server 127.0.0.1:4245 --follow --port 443 -o json | \
 python3 scripts/hubble_ingest.py --token-file secrets/dashboard_ingest_token
```

Hubble JSON의 출발지 IP/목적지 IP/TCP 목적지 포트/판정 정보를 이벤트로 변환하여 대시보드로 전송한다. **현재 방식은 host shell에서 실행되는 수집 PoC이며, Collector의 Kubernetes 상시 운영 배포는 별도 확장이 필요하다.**

## GitHub 업로드 (간단한 1개 명령)

```bash
cd /opt/opencode
bash scripts/github-push.sh
```

- `origin`: `https://github.com/yblmmen/opencode.git`, `main` 브랜치.
- `.gitignore`와 무관하게 가능한 모든 파일(설정/로그/DB/키 포함)을 등록하는 `git add -f -A` 사용.
- 인증이 필요한 첫 Push에서 GitHub **PAT**를 Password 칸에 입력. `credential.helper store`가 재사용한다.
- 인증문자열을 Git URL에 넣지 않는다. 제공된 PAT 문자열은 이 패키지에 넣지 않았다.
- Git은 빈 디렉터리와 다른 저장소 내부의 `.git` 디렉터리까지 일반 파일로 저장하지 않는다. GitHub 단일 파일 크기 제한 등은 그대로 적용된다.

## 자주 쓰는 명령어

```bash
kubectl -n opencode get pods -o wide
kubectl -n opencode logs deploy/https-dashboard --tail=50
kubectl -n opencode exec -it deploy/opencode -- opencode
bash scripts/github-push.sh
```

**파일:** `k8s/` 매니페스트, `dashboard/` 웹소스, `scripts/` 설치·업로드·Hubble 수집, `docs/architecture.drawio` 편집 가능한 구성도.

**주의:** 이 구성은 `master1`의 로컬 이미지와 `hostPath`를 사용하는 단일 노드 배포이다. 다른 노드에서 실행하려면 이미지 레지스트리와 스토리지 구성을 변경해야 한다. 실환경 Kubernetes 배포는 사용자 서버에서 검증해야 한다.
