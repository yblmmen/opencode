import importlib.util
import json
import os
import tempfile
import time
import unittest
from pathlib import Path
from xml.etree import ElementTree

HERE = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('dashboard_server', HERE/'dashboard/server.py')
server = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(server)

class DashboardTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        server.DB_PATH = str(Path(self.tmp.name)/'events.sqlite3')
        server.init_db()

    def tearDown(self):
        self.tmp.cleanup()

    def test_validation(self):
        row = server.validate_event({'src':'192.0.2.10','dst':'198.51.100.20','result':'success'})
        self.assertEqual(row[1], '192.0.2.10')
        for item in ({'src': 'not-an-ip','dst':'198.51.100.20'},
                     {'src': '192.0.2.1','dst': '198.51.100.20','dst_port': 65536},
                     {'src': '192.0.2.1','dst': '198.51.100.20','result': 'rooted'}):
            with self.assertRaises(ValueError):
                server.validate_event(item)

    def test_query_and_drawio(self):
        row = server.validate_event({'src':'192.0.2.10','dst':'198.51.100.20','bytes_in':10,'bytes_out':5})
        with server.connect() as db:
            db.execute('''INSERT INTO events(ts,src,dst,dst_port,result,bytes_in,bytes_out,duration_ms)
                          VALUES (?,?,?,?,?,?,?,?)''', row)
        stats = server.query_stats(5)
        self.assertEqual(stats['metrics']['total'], 1)
        self.assertEqual(stats['metrics']['bytes_total'], 15)
        root = ElementTree.fromstring(server.drawio_xml(stats))
        self.assertEqual(root.tag, 'mxfile')
        self.assertEqual(len(root.findall('.//mxCell[@edge="1"]')), 1)
        self.assertEqual(len(root.findall('.//mxCell[@vertex="1"]')), 2)

if __name__ == '__main__':
    unittest.main()
