import unittest
from scripts.hubble_ingest import flow_to_event


class FlowTest(unittest.TestCase):
    def test_forwarded(self):
        f = {"flow": {"IP": {"source": "10.0.0.1", "destination": "10.0.0.2"},
                      "l4": {"TCP": {"source_port": 43210, "destination_port": 443}},
                      "verdict": "FORWARDED"}}
        r = flow_to_event(f)
        self.assertEqual(r['src'], '10.0.0.1')
        self.assertEqual(r['dst'], '10.0.0.2')
        self.assertEqual(r['result'], 'success')

    def test_drop(self):
        f = {"flow": {"IP": {"source": "10.0.0.1", "destination": "10.0.0.2"},
                      "l4": {"TCP": {"destination_port": 443}}, "verdict": "DROPPED"}}
        self.assertEqual(flow_to_event(f)['result'], 'denied')

    def test_not_https(self):
        f = {"flow": {"IP": {"source": "10.0.0.1", "destination": "10.0.0.2"},
                      "l4": {"TCP": {"destination_port": 80}}, "verdict": "FORWARDED"}}
        self.assertIsNone(flow_to_event(f))


if __name__ == '__main__':
    unittest.main()
