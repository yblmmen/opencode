#!/usr/bin/env python3
"""Read Hubble observe -o json from stdin, POST TCP/443 *flow events* to local dashboard.

Usage: hubble observe --server 127.0.0.1:4245 --follow --port 443 -o json |
       python3 scripts/hubble_ingest.py --token-file secrets/dashboard_ingest_token
Never call Hubble UI https://hubble.innerinfo.org as if it were the gRPC relay.
"""
import argparse
import ipaddress
import json
import sys
import time
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError


def flow_to_event(obj):
    flow = obj.get("flow", obj)
    ip = flow.get("IP") or flow.get("ip") or {}
    l4 = flow.get("l4") or flow.get("L4") or {}
    tcp = l4.get("TCP") or l4.get("tcp") or {}
    if not tcp:
        return None
    port = tcp.get("destination_port") or tcp.get("destinationPort")
    if str(port) != "443":
        return None
    try:
        src = str(ipaddress.ip_address(ip.get("source", "")))
        dst = str(ipaddress.ip_address(ip.get("destination", "")))
    except ValueError:
        return None
    verdict = str(flow.get("verdict", "")).upper()
    if verdict == "DROPPED":
        outcome = "denied"
    elif verdict in ("FORWARDED", "REDIRECTED", "TRACED"):
        outcome = "success"
    else:
        outcome = "error"
    return {"ts": int(time.time()), "src": src, "dst": dst,
            "dst_port": 443, "result": outcome,
            "bytes_in": 0, "bytes_out": 0, "duration_ms": 0}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--url", default="http://127.0.0.1:18080/api/events")
    p.add_argument("--token-file", default="secrets/dashboard_ingest_token")
    args = p.parse_args()
    with open(args.token_file, encoding="utf-8") as f:
        token = f.read().strip()
    count = 0
    for line in sys.stdin:
        if not line.strip():
            continue
        try:
            raw = json.loads(line)
            event = flow_to_event(raw)
            if event is None:
                continue
            data = json.dumps(event).encode("utf-8")
            request = Request(args.url, data=data, headers={"Content-Type": "application/json",
                       "Authorization": "Bearer " + token}, method="POST")
            with urlopen(request, timeout=5) as response:
                if response.status != 202:
                    print("Unexpected status:", response.status, file=sys.stderr)
                    continue
            count += 1
            if count % 10 == 0:
                print(f"Forwarded {count} Hubble flow events", file=sys.stderr)
        except (ValueError, KeyError, HTTPError, URLError, OSError) as err:
            print(f"Skip/error: {err}", file=sys.stderr)
    print(f"Stream ended; forwarded {count} events", file=sys.stderr)


if __name__ == "__main__":
    main()
