#!/usr/bin/env bash
# Run from /opt/opencode after cloning github.com/yblmmen/opencode.
set -euo pipefail
cd /opt/opencode
REPO='https://github.com/yblmmen/opencode.git'
if [[ ! -d .git ]]; then
  echo 'ERROR: .git missing. Clone the existing repository to /opt/opencode first.' >&2
  exit 1
fi
git config --global credential.helper store
if git remote get-url origin >/dev/null 2>&1; then
  git remote set-url origin "$REPO"
else
  git remote add origin "$REPO"
fi
BRANCH="$(git branch --show-current)"
if [[ "$BRANCH" != main ]]; then
  echo "ERROR: current branch is '$BRANCH', expected 'main'. Verify branch before changing it." >&2
  exit 1
fi
# User explicitly requested all runtime files, including config/data/secrets.
# This may expose credentials and live data on GitHub, even if the repo is private.
git add -f -A
if git diff --cached --quiet; then
  echo 'No new changes.'
else
  git commit -m "OpenCode full update $(date +%Y-%m-%d_%H-%M)"
fi
git push -u origin main
