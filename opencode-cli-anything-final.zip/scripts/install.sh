#!/usr/bin/env bash
# Fresh install on master1: OpenCode + CLI-Anything + HTTPS dashboard (Kubernetes).
set -euo pipefail
ROOT=/opt/opencode
cd "$ROOT"
for bin in git docker kubectl; do command -v "$bin" >/dev/null || { echo "ERROR: $bin required" >&2; exit 1; }; done
kubectl get node master1 >/dev/null || { echo 'ERROR: Kubernetes node master1 not found. Edit nodeSelector in k8s/*.yaml.' >&2; exit 1; }
command -v openssl >/dev/null || { echo 'ERROR: openssl required' >&2; exit 1; }
mkdir -p config/commands data/share data/cache secrets /home/toss
if [[ ! -s secrets/ollama_api_key ]]; then
  read -rsp 'Ollama API key (not GitHub PAT): ' KEY; echo
  [[ -n "$KEY" ]] || { echo 'API key must not be empty'; exit 1; }
  (umask 077; printf '%s' "$KEY" > secrets/ollama_api_key)
  unset KEY
fi
if [[ ! -s secrets/dashboard_ingest_token ]]; then
  (umask 077; openssl rand -hex 32 > secrets/dashboard_ingest_token)
fi
chmod 600 secrets/ollama_api_key secrets/dashboard_ingest_token
if [[ ! -f CLI-Anything/cli-anything-plugin/HARNESS.md ]]; then
  git clone --depth 1 https://github.com/HKUDS/CLI-Anything.git CLI-Anything
fi
# Store upstream files as ordinary files in the user's opencode Git repo.
if [[ -d CLI-Anything/.git ]]; then rm -rf CLI-Anything/.git; fi
shopt -s nullglob
cmds=(CLI-Anything/opencode-commands/*.md)
(( ${#cmds[@]} > 0 )) || { echo 'ERROR: CLI-Anything command files absent'; exit 1; }
cp "${cmds[@]}" config/commands/
cp CLI-Anything/cli-anything-plugin/HARNESS.md config/commands/
# Project working dir is /home/toss, so use a stable methodology path.
sed -i 's#\./HARNESS\.md#/root/.config/opencode/commands/HARNESS.md#g' config/commands/cli-anything*.md
cat > config/commands/hubble-drawio.md <<'PROMPT'
---
description: Extend Hubble flow dashboard and editable draw.io exporter
---
Review source at /workspace/opencode-project/dashboard and /workspace/opencode-project/scripts/hubble_ingest.py.
Use existing Hubble L3/L4 flow events, do not describe events as concurrent TLS sessions.
Make changes with tests and explain any external data prerequisites.
User request: $ARGUMENTS
PROMPT
# Avoid Docker and Kubernetes writing to the same persisted runtime data.
if docker ps --format '{{.Names}} {{.Image}}' | grep -Eq '(^|[[:space:]])opencode-opencode-run|local/opencode:2\.0\.7([[:space:]]|$)'; then
  echo 'ERROR: existing OpenCode Docker container is running. Stop it before installation.' >&2
  exit 1
fi
printf '\n[1/4] Building images...\n'
docker build --progress=plain -f Dockerfile -t local/opencode:2.0.7-cli .
docker build --progress=plain -f Dockerfile.dashboard -t local/https-dashboard:0.1.0 .
RUNTIME="$(kubectl get node master1 -o jsonpath='{.status.nodeInfo.containerRuntimeVersion}')"
echo "Node runtime: $RUNTIME"
if [[ "$RUNTIME" == containerd* ]]; then
  command -v ctr >/dev/null || { echo 'ERROR: ctr CLI required on master1 for containerd import' >&2; exit 1; }
  echo '[2/4] Loading locally built images into containerd...'
  docker save local/opencode:2.0.7-cli | ctr -n k8s.io images import -
  docker save local/https-dashboard:0.1.0 | ctr -n k8s.io images import -
else
  echo "ERROR: only local containerd import automated; runtime=$RUNTIME" >&2
  exit 1
fi
install -d -m 0750 -o 10001 -g 10001 "$ROOT/dashboard-data"
echo '[3/4] Creating namespace and secrets...'
kubectl apply -f k8s/00-namespace.yaml
TMP_DIR="$(mktemp -d)"; trap 'rm -rf "$TMP_DIR"' EXIT
chmod 700 "$TMP_DIR"
printf '%s' "$(cat secrets/ollama_api_key)" > "$TMP_DIR/ollama"
printf '%s' "$(cat secrets/dashboard_ingest_token)" > "$TMP_DIR/ingest"
kubectl -n opencode create secret generic ollama-api-key --from-file="OLLAMA_API_KEY=$TMP_DIR/ollama" --dry-run=client -o yaml | kubectl apply -f -
kubectl -n opencode create secret generic dashboard-ingest --from-file="token=$TMP_DIR/ingest" --dry-run=client -o yaml | kubectl apply -f -
echo '[4/4] Deploying...'
kubectl apply -f k8s/10-opencode.yaml -f k8s/20-dashboard.yaml
kubectl -n opencode rollout restart deployment/opencode deployment/https-dashboard
kubectl -n opencode rollout status deployment/opencode --timeout=180s
kubectl -n opencode rollout status deployment/https-dashboard --timeout=180s
kubectl -n opencode get pods -o wide
echo 'DONE. OpenCode: kubectl -n opencode exec -it deploy/opencode -- opencode'
echo 'Dashboard: kubectl -n opencode port-forward svc/https-dashboard 18080:8080'
