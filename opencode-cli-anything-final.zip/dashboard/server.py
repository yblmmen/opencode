#!/usr/bin/env python3
"""Local-first HTTPS session-EVENT dashboard. No packet capture, TLS decryption, or proxy built in."""
import hmac
import ipaddress
import json
import os
import sqlite3
import time
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit, parse_qs
from xml.etree import ElementTree as ET

DB_PATH = os.environ.get("DB_PATH", "/data/sessions.sqlite3")
TOKEN = os.environ.get("INGEST_TOKEN", "")
STATIC = Path(__file__).resolve().parent / "index.html"
SCRIPT = Path(__file__).resolve().parent / "main.js"
MAX_BODY = 65536
MAX_BATCH = 100


def connect():
    db = sqlite3.connect(DB_PATH, timeout=10)
    db.row_factory = sqlite3.Row
    return db


def init_db():
    Path(DB_PATH).parent.mkdir(parents=True, exist_ok=True)
    with connect() as db:
        db.execute("PRAGMA journal_mode=WAL")
        db.execute("""CREATE TABLE IF NOT EXISTS events (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          ts INTEGER NOT NULL,
          src TEXT NOT NULL,
          dst TEXT NOT NULL,
          dst_port INTEGER NOT NULL,
          result TEXT NOT NULL,
          bytes_in INTEGER NOT NULL,
          bytes_out INTEGER NOT NULL,
          duration_ms INTEGER NOT NULL
        )""")
        db.execute("CREATE INDEX IF NOT EXISTS ix_events_ts ON events(ts)")


def validate_event(event):
    if not isinstance(event, dict):
        raise ValueError("event must be a JSON object")
    try:
        src = str(ipaddress.ip_address(event["src"]))
        dst = str(ipaddress.ip_address(event["dst"]))
        port = int(event.get("dst_port", 443))
        result = event.get("result", "success")
        incoming = int(event.get("bytes_in", 0))
        outgoing = int(event.get("bytes_out", 0))
        duration = int(event.get("duration_ms", 0))
        supplied_ts = event.get("ts", None)
        if supplied_ts is None:
            timestamp = int(time.time())
        elif isinstance(supplied_ts, (float, int)):
            timestamp = int(supplied_ts)
        else:
            # Accept RFC3339 with an explicit time zone only
            parsed = datetime.fromisoformat(str(supplied_ts).replace("Z", "+00:00"))
            if parsed.tzinfo is None:
                raise ValueError("ts requires timezone")
            timestamp = int(parsed.timestamp())
    except (ValueError, TypeError, KeyError, OverflowError) as exc:
        raise ValueError(f"invalid event: {exc}") from exc
    if not 1 <= port <= 65535 or result not in ("success", "denied", "error"):
        raise ValueError("dst_port or result invalid")
    if not (0 <= incoming <= 10**15 and 0 <= outgoing <= 10**15 and 0 <= duration <= 10**9):
        raise ValueError("bytes/duration out of range")
    if abs(timestamp - time.time()) > 86400 * 31:
        raise ValueError("timestamp outside 31-day import window")
    return (timestamp, src, dst, port, result, incoming, outgoing, duration)


def query_stats(minutes):
    since = int(time.time()) - minutes * 60
    with connect() as db:
        total = db.execute("""SELECT COUNT(*) AS total,
              COALESCE(SUM(result = 'success'),0) AS success,
              COALESCE(SUM(result = 'denied'),0) AS denied,
              COALESCE(SUM(result = 'error'),0) AS error,
              COALESCE(SUM(bytes_in + bytes_out),0) AS bytes_total
              FROM events WHERE ts >= ?""", (since,)).fetchone()
        edges = db.execute("""SELECT src,dst,dst_port, COUNT(*) AS count,
                     SUM(result != 'success') AS failures
                     FROM events WHERE ts >= ?
                     GROUP BY src,dst,dst_port ORDER BY count DESC LIMIT 12""", (since,)).fetchall()
        latest = db.execute("""SELECT ts,src,dst,dst_port,result,bytes_in,bytes_out,duration_ms
                             FROM events WHERE ts >= ? ORDER BY ts DESC, id DESC LIMIT 50""", (since,)).fetchall()
        slots = db.execute("""SELECT CAST(ts/60 AS INTEGER) AS minute, COUNT(*) AS count
                  FROM events WHERE ts >= ? GROUP BY minute ORDER BY minute""", (since,)).fetchall()
    return {
      "window_minutes": minutes,
      "generated_at": int(time.time()),
      "metrics": dict(total),
      "edges": [dict(r) for r in edges],
      "latest": [dict(r) for r in latest],
      "timeline": [dict(r) for r in slots],
      "note": "Counts are normalized flow/session EVENT records, not current concurrent TCP sessions."
    }


def drawio_xml(stats):
    """Produce valid editable mxGraph .drawio XML from recent observed events."""
    mxfile = ET.Element("mxfile", {"host": "app.diagrams.net", "version": "24.7.17"})
    diagram = ET.SubElement(mxfile, "diagram", {"name": "Observed HTTPS flows", "id": "liveflows"})
    graph = ET.SubElement(diagram, "mxGraphModel", {"dx": "1200", "dy": "800", "grid": "1",
        "gridSize": "10", "guides": "1", "tooltips": "1", "connect": "1", "arrows": "1",
        "fold": "1", "page": "1", "pageScale": "1", "pageWidth": "1169", "pageHeight": "827"})
    root = ET.SubElement(graph, "root")
    ET.SubElement(root, "mxCell", {"id": "0"})
    ET.SubElement(root, "mxCell", {"id": "1", "parent": "0"})
    edges = stats["edges"][:8]
    sources = list(dict.fromkeys(e["src"] for e in edges))
    destinations = list(dict.fromkeys(f'{e["dst"]}:{e["dst_port"]}' for e in edges))

    def vertex(name, value, x, y, fill):
        cell = ET.SubElement(root, "mxCell", {
          "id": name, "value": value, "style": f"rounded=1;whiteSpace=wrap;html=1;fillColor={fill};strokeColor=#64748b;fontSize=13;",
          "vertex": "1", "parent": "1"
        })
        ET.SubElement(cell, "mxGeometry", {"x": str(x), "y": str(y), "width": "240", "height": "44", "as": "geometry"})

    for i, src in enumerate(sources):
        vertex(f"s{i}", src, 50, 110 + 75*i, "#DBEAFE")
    for j, dst in enumerate(destinations):
        vertex(f"d{j}", dst, 720, 110 + 75*j, "#D1FAE5")
    for k, edge in enumerate(edges):
        dest_key = f'{edge["dst"]}:{edge["dst_port"]}'
        label = f'{edge["count"]} observed event(s), {edge["failures"]} non-success'
        cell = ET.SubElement(root, "mxCell", {
          "id": f"e{k}", "value": label,
          "style": "edgeStyle=orthogonalEdgeStyle;rounded=1;html=1;endArrow=block;strokeColor=#64748b;fontSize=11;",
          "edge": "1", "parent": "1", "source": f's{sources.index(edge["src"])}',
          "target": f'd{destinations.index(dest_key)}'
        })
        ET.SubElement(cell, "mxGeometry", {"relative": "1", "as": "geometry"})
    return ET.tostring(mxfile, encoding="utf-8", xml_declaration=True)


class Handler(BaseHTTPRequestHandler):
    def send(self, code, content, content_type="application/json; charset=utf-8", attachment=None):
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(content)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Content-Security-Policy", "default-src 'self'; img-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; object-src 'none'; frame-ancestors 'none'")
        if attachment:
            self.send_header("Content-Disposition", f'attachment; filename="{attachment}"')
        self.end_headers()
        self.wfile.write(content)

    def json_response(self, code, payload):
        self.send(code, json.dumps(payload, ensure_ascii=False).encode("utf-8"))

    def do_GET(self):
        parsed = urlsplit(self.path)
        if parsed.path == "/healthz":
            self.json_response(200, {"status": "ok"})
        elif parsed.path in ("/", "/index.html"):
            self.send(200, STATIC.read_bytes(), "text/html; charset=utf-8")
        elif parsed.path == "/main.js":
            self.send(200, SCRIPT.read_bytes(), "text/javascript; charset=utf-8")
        elif parsed.path in ("/api/summary", "/api/export.drawio"):
            try:
                minutes = int(parse_qs(parsed.query).get("minutes", ["60"])[0])
                if minutes not in (5, 15, 60, 180, 1440):
                    raise ValueError("window must be 5,15,60,180,1440")
                stats = query_stats(minutes)
            except (ValueError, TypeError) as e:
                self.json_response(400, {"error": str(e)})
                return
            if parsed.path == "/api/export.drawio":
                self.send(200, drawio_xml(stats), "application/xml; charset=utf-8", "https-sessions.drawio")
            else:
                self.json_response(200, stats)
        else:
            self.json_response(404, {"error": "not found"})

    def do_POST(self):
        if urlsplit(self.path).path != "/api/events":
            self.json_response(404, {"error": "not found"})
            return
        auth = self.headers.get("Authorization", "")
        if not TOKEN or not hmac.compare_digest(auth, "Bearer " + TOKEN):
            self.json_response(401, {"error": "invalid ingest token"})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if not 0 < length <= MAX_BODY:
                raise ValueError("request body too large or empty")
            payload = json.loads(self.rfile.read(length))
            items = payload if isinstance(payload, list) else [payload]
            if not 1 <= len(items) <= MAX_BATCH:
                raise ValueError("batch must be 1..100 events")
            events = [validate_event(item) for item in items]
            with connect() as db:
                db.executemany("""INSERT INTO events
                   (ts,src,dst,dst_port,result,bytes_in,bytes_out,duration_ms)
                   VALUES(?,?,?,?,?,?,?,?)""", events)
            self.json_response(202, {"accepted": len(events)})
        except (ValueError, UnicodeError, json.JSONDecodeError) as e:
            self.json_response(400, {"error": str(e)})
        except sqlite3.Error:
            self.json_response(500, {"error": "database write failure"})


def main():
    if not TOKEN:
        raise SystemExit("INGEST_TOKEN must be set; refusing insecure startup")
    init_db()
    port = int(os.environ.get("PORT", "8080"))
    print(f"HTTPS session event dashboard listening on 0.0.0.0:{port}", flush=True)
    ThreadingHTTPServer(("0.0.0.0", port), Handler).serve_forever()


if __name__ == "__main__":
    main()
