# OpenCode + CLI-Anything 최종 설치 매뉴얼

**기준:** master1 / `/opt/opencode` / Kubernetes 네임스페이스 `opencode` / GitHub `https://github.com/yblmmen/opencode.git` / `main`

## 설치 4단계

1) 빈 서버라면 GitHub 저장소를 내려받습니다. 기존 설치 서버는 백업 후 `/opt/opencode`의 `.git`을 유지하고 2단계로 이동합니다.

```bash
git config --global credential.helper store
git clone https://github.com/yblmmen/opencode.git /opt/opencode
```

2) 패키지 파일을 `/root/opencode-cli-anything-final.zip`에 복사한 뒤 압축을 해제합니다.

```bash
unzip -o /root/opencode-cli-anything-final.zip -d /opt/opencode
cd /opt/opencode
```

3) 기존 Docker OpenCode를 중지한 후 설치합니다. 새 서버라면 중지할 컨테이너가 없습니다.

```bash
docker ps
# 기존 OpenCode 실행 컨테이너가 있을 때만: docker stop <실제 컨테이너 이름 또는 ID>
bash scripts/install.sh
```

4) 상태 및 접속을 확인합니다.

```bash
kubectl -n opencode get pods -o wide
kubectl -n opencode exec -it deploy/opencode -- opencode
```

OpenCode에서 `/cli-anything-list` 명령이 보이면 명령어 연동은 성공한 것입니다. `/cli-anything /home/toss/프로젝트경로`로 프로그램 소스에서 CLI 생성 작업을 진행할 수 있습니다.

## 대시보드와 Draw.io

```bash
kubectl -n opencode port-forward svc/https-dashboard 18080:8080
```

브라우저에서 `http://127.0.0.1:18080` 접속. 화면에서 `.drawio`를 내보낼 수 있습니다. 현재 구성은 실시간 이벤트 집계 UI이며, 실제 Hubble 연결을 위해 아래 추가 명령이 필요합니다.

```bash
kubectl get svc -A | grep hubble-relay
# 터미널 1: 포트가 80일 때 예시
kubectl -n kube-system port-forward svc/hubble-relay 4245:80
# 터미널 2: master1에 hubble CLI가 설치되어 있고 대시보드 포트포워딩이 실행 중일 때
cd /opt/opencode
hubble observe --server 127.0.0.1:4245 --follow --port 443 -o json | python3 scripts/hubble_ingest.py
```

HTTPS 통신의 **Hubble Flow 이벤트 수**를 표시하는 것으로, TLS 복호화나 실제 활성 세션 수 측정은 아닙니다. `hubble.innerinfo.org` Hubble UI는 변경하지 않습니다.

## GitHub: 최초 Push + 이후 Push

```bash
cd /opt/opencode
bash scripts/github-push.sh
```

최초 Push에만 Username `yblmmen`, Password에는 GitHub PAT를 입력하십시오. 이후에는 `/root/.git-credentials`를 통해 자동 인증합니다. 파일을 전부 올리도록 `git add -f -A`를 실행하도록 구성했습니다.

직접 Git 명령만 사용할 경우:

```bash
cd /opt/opencode
git config --global credential.helper store
git add -f -A
git commit -m 'Update OpenCode project'
git push -u origin main
```

`git clone`으로 시작하면 기존 GitHub 커밋 이력을 보존하므로 별도 `git init`과 `git remote add origin`은 필요하지 않습니다. 로컬 디렉터리에 이미 `.git`이 있으면 새로 초기화하지 마십시오.

## 문제 발생 시 확인

```bash
kubectl get nodes -o wide
kubectl -n opencode get pods -o wide
kubectl -n opencode describe pod -l app=opencode
kubectl -n opencode logs deploy/https-dashboard --tail=100
ls -l /opt/opencode/config/commands/
git remote -v
```

- `ImagePullBackOff` / 이미지 없음: Docker 이미지가 containerd에 import 되었는지 확인.
- `Pending`: master1 노드명, taint, hostPath 디렉터리 확인.
- `/cli-anything` 미표시: `config/commands/*.md` 및 OpenCode 재실행 확인.
- Git Push `403`: PAT의 `Contents: Read and write`, 대상 리포지토리 `opencode` 선택 확인.
- Git Push `non-fast-forward`: 기존 원격 이력을 먼저 가져와야 합니다. 강제 Push를 자동 수행하지 않습니다.
- OpenCode 세션 DB: 프로세스가 실행 중일 때 DB/WAL/SHM을 일반 Git 파일로 복사하는 것은 일관된 백업을 보장하지 않습니다.

> 배포 스크립트는 root로 실행하고 node `master1`, containerd, Docker 빌드가 가능한 단일 호스트 Kubernetes를 전제로 합니다. 실제 운영환경의 클러스터에서 실행 검증한 패키지는 아닙니다.
