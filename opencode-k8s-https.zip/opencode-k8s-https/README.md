# OpenCode + CLI-Anything + HTTPS Session Event Dashboard (Kubernetes)

**For the exact example layout**: Kubernetes node `master1`, OpenCode root `/opt/opencode`, workspace `/home/toss`, namespace `opencode`. Inherits the supplied Compose host-mount layout. The stack is a **single-node pilot**, not a production HA design. Uses the existing prebuilt local Compose image `local/opencode:2.0.7` as its base (itself originally built from `ghcr.io/anomalyco/opencode:2.0.7`), preserving installed dependencies.

## Scope and limitations

- OpenCode TUI is accessed using `kubectl exec -it`, **not** exposed over HTTP.
- CLI-Anything OpenCode markdown commands are added to the existing host config (`/opt/opencode/config/commands`), which is mounted at `/root/.config/opencode` in the pod.
- Dashboard is a working web UI + SQLite REST ingestion prototype, using only Python standard library. No CDN or PyPI at runtime.
- Dashboard displays submitted **normalized session/flow event records** (not concurrently established TCP sessions, actual HTTPS handshake traces, or HTTP requests). It does not capture packets or ingest FortiGate syslog by itself.
- `.drawio` export is generated on demand from recent observed flows, without requiring a graphical Draw.io desktop application. CLI-Hub Draw.io integration is OPTIONAL, with extra desktop/Xvfb and potentially glibc requirements.
- Pilot-only exposure: dashboard `ClusterIP`, access via local `kubectl port-forward`. It has a bearer token for ingest but **no viewer authentication**, so do not expose the Service via Ingress/NodePort/LoadBalancer without protecting it first.
- Both workloads stay pinned to `master1` and hostPath; cluster failover and automatic persistence migration are not provided. Never scale them above 1 replica.

## Step 0. Verify Kubernetes before any changes

```bash
kubectl cluster-info
kubectl get nodes -o wide
kubectl get node master1 --show-labels
kubectl get node master1 -o jsonpath='{.status.nodeInfo.containerRuntimeVersion}{"\n"}'
kubectl get storageclass
ls -la /opt/opencode/{config,data/share,data/cache,secrets/ollama_api_key}
ls -ld /home/toss
```

If there is **no** schedulable node actually named `master1`, update `nodeSelector` in **both** deployments. For hostPath, the scheduled node must have the *same real data* on those paths. For production, migrate data to a PVC using an appropriate StorageClass/CSI driver, a registry, and non-root users. A control-plane taint tolerance is included for this requested initial node, but using a worker is preferable.

## Step 1. Back up the existing Compose environment

```bash
cd /opt/opencode
umask 077
tar -czf /root/opencode-backup-$(date +%F-%H%M).tgz -C /opt \
  opencode/config opencode/data opencode/secrets
```

The archive includes credentials: encrypt, protect and dispose of it per local policy. Verify the backup before stopping Compose. Avoid accessing the same live OpenCode state from Docker and Kubernetes simultaneously. Because the provided Docker container is a one-off `docker compose run` container, identify the exact container ID with `docker ps` and stop it manually when ready for cutover:

```bash
docker ps --filter name=opencode
# DO THIS ONLY AFTER BACKUP and maintenance window:
# docker stop 0b1b02190b97
```

Do not run `docker compose down -v` or remove existing config/share volumes.

## Step 2. Unpack the package and install CLI-Anything commands

Extract `opencode-k8s-https.zip` **as a directory under** `/opt/opencode/`; it will produce `/opt/opencode/opencode-k8s-https`.

```bash
cd /opt/opencode/opencode-k8s-https
bash scripts/prepare-cli-anything.sh
ls -la /opt/opencode/config/commands/
```

This clones `https://github.com/HKUDS/CLI-Anything.git` to `/opt/opencode/CLI-Anything`. It copies official command files and HARNESS.md into the **existing host configuration directory**, then replaces `./HARNESS.md` with the correct **container-absolute** `/root/.config/opencode/commands/HARNESS.md` reference. It also adds `/https-session-dashboard`. The script preserves all other existing config files. Inspect command contents before use, as they become AI instructions. Git SHA is printed for later reproducibility.

## Step 3. Build two images on master1

```bash
cd /opt/opencode/opencode-k8s-https
bash scripts/build-images.sh
```

The OpenCode build expects the existing `local/opencode:2.0.7` image to be present in Docker on `master1`. Do not remove it during cutover. Expected names:
- `local/opencode:2.0.7-cli` (OpenCode + Python3 + git + shell tools).
- `local/https-session-dashboard:0.1.0` (Python 3.12 stdlib dashboard).

**Docker build does NOT imply the images are visible to a Kubernetes containerd runtime.** If the `master1` kubelet uses containerd, run:

```bash
sudo bash scripts/load-containerd.sh
sudo ctr -n k8s.io images ls | grep -E 'opencode|https-session-dashboard'
```

The script uses `docker save` and `ctr -n k8s.io images import` with a temporary tar. If the cluster uses CRI-O, remote nodes, or another runtime, publish both images to an approved registry instead and change image references plus `imagePullPolicy` accordingly. `imagePullPolicy: Never` works only if both names are already in the selected node's CRI image store.

## Step 4. Deploy

After stopping the OLD Docker OpenCode container (so the old session state is not written by two processes):

```bash
cd /opt/opencode/opencode-k8s-https
sudo bash scripts/deploy.sh
kubectl -n opencode get pod,deploy,svc -o wide
```

The deploy script creates namespace `opencode`, copies the **existing** Ollama API-key file into Kubernetes Secret `ollama-api-key`, generates a new HTTP-ingest token in `/opt/opencode/secrets/dashboard_ingest_token` (mode 0600) and Secret `dashboard-ingest`, creates `/opt/opencode/dashboard-data` owned by UID 10001 for SQLite, then applies both deployments and waits for rollout. Be aware of Kubernetes etcd Secret encryption and RBAC controls. It does **not** expose secrets in the YAML. The `kubectl` user must have namespace/Secret/Deployment creation permissions.

## Step 5. OpenCode TUI

```bash
kubectl -n opencode exec -it deployment/opencode -- opencode
```

Alternatively:

```bash
kubectl -n opencode exec -it deployment/opencode -- /bin/sh
opencode --version
python3 --version
ls -l /root/.config/opencode/commands
opencode
```

The deployment additionally mounts `/opt/opencode/opencode-k8s-https` as `/workspace/https-monitor`, allowing OpenCode to read and modify the dashboard application and YAML manifests. In the OpenCode **TUI prompt**: `/cli-anything-list`, `/cli-anything`, and `/https-session-dashboard <request>` should be discoverable. The command files are AI prompt templates, not host executable binaries. First test against a disposable source project, not a production repository. Base image remains 2.0.7 to preserve compatibility; upgrades should be separately tested because CLI-Anything labels OpenCode support experimental.

## Step 6. Open the dashboard

Run on master1:

```bash
kubectl -n opencode port-forward svc/https-dashboard 18080:8080 --address 127.0.0.1
```

On master1 itself: `http://127.0.0.1:18080`. To view from a workstation, additionally make an SSH tunnel from that workstation:

```bash
ssh -L 18080:127.0.0.1:18080 <ssh-user>@master1
```

Then open `http://127.0.0.1:18080` on the workstation. The initial dashboard is empty, **by design**, until events arrive.

## Step 7. Demo test: fake observations only

On the master1 host in another terminal, with port-forward active:

```bash
cd /opt/opencode/opencode-k8s-https
python3 scripts/send-demo.py
```

The script authenticates using the local token file and inserts 85 **artificial** events using reserved documentation ranges (RFC5737). No real HTTPS sessions are measured. Refresh the browser and download **Draw.io 내보내기** to obtain an editable `.drawio` XML drawing of the observed (in this case demo) flows.

To send a real normalized event, run from a secured collector host with access to the dashboard (adjust endpoint via approved internal networking, **never publish unauthenticated viewer routes**):

```json
{
  "ts": "2026-10-25T04:10:00Z",
  "src": "192.0.2.10",
  "dst": "198.51.100.20",
  "dst_port": 443,
  "result": "success",
  "bytes_in": 18200,
  "bytes_out": 6700,
  "duration_ms": 830
}
```

`POST /api/events`, with header `Authorization: Bearer <INGEST_TOKEN>` and `Content-Type: application/json`, accepts one event or a JSON array of up to 100 events (max body 64 KiB). `result` is one of `success`, `denied`, `error`. `src`/`dst` must be IP addresses. `ts` is epoch seconds or an ISO8601 time with timezone; omitted `ts` means server reception time. Only post observations that your sensor can accurately support.

The API does not provide deduplication, retention, connection-lifecycle tracking, or authentication for viewers. Any number shown corresponds to **incoming events**, not active connections. Prioritize these changes before operational rollout.

## Step 8. Optional CLI-Hub / Draw.io

OpenCode slash commands are already installed without CLI-Hub. For a separate optional **CLI-Hub installation**, use a persistent virtual environment inside your workspace:

```bash
kubectl -n opencode exec -it deployment/opencode -- /bin/sh
python3 -m venv /home/toss/.venvs/cli-hub
/home/toss/.venvs/cli-hub/bin/pip install --upgrade pip
/home/toss/.venvs/cli-hub/bin/pip install cli-anything-hub
/home/toss/.venvs/cli-hub/bin/cli-hub search diagram
/home/toss/.venvs/cli-hub/bin/cli-hub info drawio
```

**Do not assume** `cli-hub install drawio` alone creates a working headless Draw.io exporter inside this Alpine container: CLI-Anything Draw.io docs require the Draw.io desktop application and appropriate GUI/renderer dependencies. The bundled dashboard instead exports fully editable Draw.io XML without Draw.io installed. For automated `.png` export, use an approved separate GUI-capable conversion container or workstation.

## Operations and migration notes

```bash
kubectl -n opencode get pods -o wide
kubectl -n opencode logs deploy/https-dashboard --tail=50
kubectl -n opencode describe pod -l app=opencode
kubectl -n opencode rollout restart deploy/opencode
kubectl -n opencode rollout restart deploy/https-dashboard
kubectl -n opencode delete -f k8s/30-dashboard.yaml -f k8s/20-opencode.yaml
```

`kubectl delete` removes deployment objects, **not** `/opt/opencode/config`, `/opt/opencode/data`, `/home/toss`, or `/opt/opencode/dashboard-data` hostPath files. Secrets created by deploy.sh remain in namespace; remove separately if appropriate. To roll back to Docker, first stop Kubernetes deployment writers and verify original files before restarting the previous Compose image.

### Common issues

| Symptom | Likely action |
| --- | --- |
| `ImagePullBackOff` or `ErrImageNeverPull` | Import/push images into the node's actual CRI image store. |
| Pod `Pending` | Check `kubectl get nodes`, `kubectl describe pod`; selector, taints, memory, and image locations. |
| `CreateContainerConfigError` | Verify Secrets `ollama-api-key` / `dashboard-ingest` and hostPath folders. |
| OpenCode command missing | Check `/opt/opencode/config/commands/*.md` on host; exec into Pod and check `/root/.config/opencode/commands/`. |
| Dashboard SQLite `Permission denied` | Host `/opt/opencode/dashboard-data` must be writable by uid 10001; also check SELinux enforcing hostPath policy. |
| OpenCode lost sessions | Confirm the original directory was `/opt/opencode/data/share` and only one writer is running. |
| Dashboard blank | This prototype has **no built-in traffic collector**; send demo records or implement a real normalized feed. |
| HTTP viewer exposed unexpectedly | Keep Service as ClusterIP; do not create unprotected Ingress/NodePort. |

### Next phase (for real HTTPS monitoring)

1. Identify source: FortiGate traffic logs (session events), reverse proxy connection logs (depends on product), LB telemetry, or conntrack/eBPF exporter.
2. Obtain 5–10 sanitized sample records including timestamp, src/dst/port, action, bytes, session ID, start/end or duration (if available). Do not share keys, credentials, sensitive payloads.
3. Implement collector/parser with backpressure and retries. Normalize `accept/deny` to UI results; include sensor and unique session ID for deduplication; preserve start/end events for **true active-session** metric.
4. Add access-controlled ingest Service or broker, mutual TLS or validated JWT, RBAC/NetworkPolicy, retention jobs, database migration, HTTPS ingress with authentication, audit and dashboard authorization.
5. Replace hostPath with PV/PVC (or database service), push versioned images to a registry, and schedule production applications on suitable worker nodes.

## Testing locally without Kubernetes

```bash
python3 -m unittest discover -s tests -v
INGEST_TOKEN=local-demo DB_PATH=/tmp/opencode-dashboard-test.sqlite3 PORT=18080 python3 dashboard/server.py
```

The `api/events` ingest endpoint requires a token. Use a separate terminal for curl or scripts.

## Primary references

- CLI-Anything: https://github.com/HKUDS/CLI-Anything
- CLI-Hub: https://clianything.cc/docs.html
- OpenCode custom commands: https://docs.opencode.ai/docs/commands/
- K8s hostPath: https://kubernetes.io/docs/concepts/storage/volumes/#hostpath
- K8s Secrets: https://kubernetes.io/docs/concepts/configuration/secret/
