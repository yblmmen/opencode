#!/usr/bin/env bash
set -euo pipefail
command -v docker >/dev/null || { echo 'docker CLI required'; exit 1; }
command -v ctr >/dev/null || { echo 'ctr not found; check CRI and registry configuration'; exit 1; }
TMP="$(mktemp -d /tmp/opencode-import.XXXXXX)"
trap 'rm -rf "${TMP}"' EXIT
for IMAGE in local/opencode:2.0.7-cli local/https-session-dashboard:0.1.0; do
  FILE="${TMP}/$(echo "${IMAGE}" | tr '/:' '_').tar"
  docker save -o "${FILE}" "${IMAGE}"
  ctr -n k8s.io images import "${FILE}"
  echo "Imported ${IMAGE} into containerd k8s.io namespace"
done
