#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
command -v docker >/dev/null || { echo "docker CLI is required for building" >&2; exit 1; }
docker build -f "${HERE}/Dockerfile.opencode" -t local/opencode:2.0.7-cli "${HERE}"
docker build -f "${HERE}/Dockerfile.dashboard" -t local/https-session-dashboard:0.1.0 "${HERE}"
printf '\nImages built locally. If Kubernetes uses containerd, run load-containerd.sh on master1.\n'
