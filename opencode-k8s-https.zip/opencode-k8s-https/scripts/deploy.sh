#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ROOT="${OPEN_CODE_ROOT:-/opt/opencode}"
command -v kubectl >/dev/null || { echo 'kubectl required'; exit 1; }
for PATH_TO_CHECK in \
  "$ROOT/config" "$ROOT/data/share" "$ROOT/data/cache" \
  "$ROOT/secrets/ollama_api_key" /home/toss; do
  [[ -e "$PATH_TO_CHECK" ]] || { echo "Missing: $PATH_TO_CHECK" >&2; exit 1; }
done
# Dashboard hostPath must already exist and be writable by uid 10001.
install -d -m 0750 -o 10001 -g 10001 "$ROOT/dashboard-data"
install -d -m 0700 "$ROOT/secrets"
TOKEN_FILE="$ROOT/secrets/dashboard_ingest_token"
if [[ ! -s "$TOKEN_FILE" ]]; then
  command -v openssl >/dev/null || { echo 'openssl required to generate ingest token' >&2; exit 1; }
  umask 077
  openssl rand -hex 32 | tr -d "\n" > "$TOKEN_FILE"
fi
chmod 600 "$TOKEN_FILE"
# Compose's $(cat /run/secrets/file) stripped final newlines.
# Kubernetes --from-file does NOT strip them, so normalize both to avoid
# authentication failures from hidden CR/LF in environment variables.
TEMP_KEYS="$(mktemp -d /tmp/opencode-secrets.XXXXXX)"
chmod 700 "$TEMP_KEYS"
trap 'rm -rf "$TEMP_KEYS"' EXIT
printf '%s' "$(cat "$ROOT/secrets/ollama_api_key")" > "$TEMP_KEYS/ollama"
printf '%s' "$(cat "$TOKEN_FILE")" > "$TEMP_KEYS/ingest"
[[ -s "$TEMP_KEYS/ollama" && -s "$TEMP_KEYS/ingest" ]] || { echo 'Empty key' >&2; exit 1; }
kubectl apply -f "$HERE/k8s/00-namespace.yaml"
kubectl -n opencode create secret generic ollama-api-key \
  --from-file="OLLAMA_API_KEY=$TEMP_KEYS/ollama" \
  --dry-run=client -o yaml | kubectl apply -f -
kubectl -n opencode create secret generic dashboard-ingest \
  --from-file="token=$TEMP_KEYS/ingest" \
  --dry-run=client -o yaml | kubectl apply -f -
kubectl apply -f "$HERE/k8s/20-opencode.yaml" -f "$HERE/k8s/30-dashboard.yaml"
kubectl -n opencode rollout status deployment/opencode --timeout=180s
kubectl -n opencode rollout status deployment/https-dashboard --timeout=180s
kubectl -n opencode get pods -o wide
