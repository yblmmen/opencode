#!/usr/bin/env bash
set -euo pipefail
ROOT="${OPEN_CODE_ROOT:-/opt/opencode}"
REPO="${ROOT}/CLI-Anything"
COMMANDS="${ROOT}/config/commands"
if [[ ! -d "${ROOT}/config" ]]; then echo "ERROR: no existing ${ROOT}/config" >&2; exit 1; fi
command -v git >/dev/null || { echo "git is required" >&2; exit 1; }
if [[ ! -d "${REPO}/.git" ]]; then
  git clone --depth 1 https://github.com/HKUDS/CLI-Anything.git "${REPO}"
else
  echo "Using existing ${REPO}; no implicit git pull to avoid changing pinned commands."
fi
shopt -s nullglob
CMD_FILES=("${REPO}"/opencode-commands/*.md)
if (( ${#CMD_FILES[@]} == 0 )) || [[ ! -f "${REPO}/cli-anything-plugin/HARNESS.md" ]]; then
  echo "ERROR: invalid CLI-Anything checkout" >&2; exit 1
fi
mkdir -p "${COMMANDS}"
cp "${CMD_FILES[@]}" "${COMMANDS}/"
cp "${REPO}/cli-anything-plugin/HARNESS.md" "${COMMANDS}/"
# OpenCode resolves plain relative paths from the current project directory,
# not the commands directory; keep the methodology pointer absolute.
sed -i 's#\./HARNESS\.md#/root/.config/opencode/commands/HARNESS.md#g' "${COMMANDS}"/cli-anything*.md
cat > "${COMMANDS}/https-session-dashboard.md" <<'PROMPT'
---
description: Develop or extend the HTTPS session dashboard and draw.io exporter
agent: build
---
Review the HTTPS monitoring project at /workspace/https-monitor/dashboard, and its Kubernetes manifests at /workspace/https-monitor/k8s. The project source is mounted from /opt/opencode/opencode-k8s-https on the host.
Keep real observed HTTPS sessions distinct from HTTP request counts.
Extend the existing local-first monitoring UI and edit-friendly .drawio exporter.
Do not access secrets, expose private keys, disable access controls, or change production resources without confirmation.
Work incrementally, add tests, and explain any missing log collector inputs.
Requested change: $ARGUMENTS
PROMPT
printf 'Installed commands:\n'
ls -1 "${COMMANDS}" | grep -E 'cli-anything|https-session|HARNESS' || true
printf '\nGit revision: '
git -C "${REPO}" rev-parse --short HEAD
