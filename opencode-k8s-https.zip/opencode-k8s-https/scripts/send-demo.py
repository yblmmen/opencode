#!/usr/bin/env python3
"""Submit RFC5737 TEST-NET example IP events to an explicitly local forwarded port."""
import argparse
import json
import random
import time
from pathlib import Path
from urllib.request import Request, urlopen

parser = argparse.ArgumentParser()
parser.add_argument('--token-file', default='/opt/opencode/secrets/dashboard_ingest_token')
parser.add_argument('--url', default='http://127.0.0.1:18080/api/events')
args = parser.parse_args()
if not args.url.startswith('http://127.0.0.1:'):
    parser.error('Demo restricts target to a local port-forward URL (127.0.0.1)')
token = Path(args.token_file).read_text().strip()
random.seed(20261025)
now = int(time.time())
clients = ['192.0.2.10', '192.0.2.11', '192.0.2.21', '192.0.2.25', '192.0.2.31']
servers = ['198.51.100.10', '198.51.100.20', '203.0.113.8']
items = []
for i in range(85):
    result = 'denied' if i % 17 == 0 else ('error' if i % 23 == 0 else 'success')
    items.append({'ts': now - random.randrange(0, 30 * 60),
                  'src': random.choice(clients), 'dst': random.choice(servers),
                  'dst_port': 443, 'result': result,
                  'bytes_in': random.randrange(200, 70000),
                  'bytes_out': random.randrange(120, 50000),
                  'duration_ms': random.randrange(40, 9000)})
body = json.dumps(items).encode()
req = Request(args.url, body, {'Content-Type': 'application/json',
                               'Authorization': 'Bearer '+token}, method='POST')
with urlopen(req, timeout=10) as resp:
    print('DEMO ONLY:', resp.status, resp.read().decode())
print('No real sensor connected. All demo IP addresses belong to RFC 5737 documentation ranges.')
