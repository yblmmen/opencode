# OpenCode + CLI-Anything + HTTPS 세션 이벤트 모니터링
## Kubernetes 설치 및 운영 매뉴얼 (master1 / opencode 네임스페이스)

작성 기준: 2026-10-25. 이 문서는 사용자가 제공한 `Dockerfile`, `compose.yml`, `ll`, `docker ps` 결과를 기반으로 한 변환본입니다. **Kubernetes 실제 클러스터에는 아직 적용하지 않았으며**, 제공된 소스의 Python 단위시험·HTTP API 통합시험·K8s YAML 파싱을 확인했습니다.

## A. 기존 Docker 환경과 Kubernetes 변환

| 기존 Compose | Kubernetes 대응 | 데이터 보존 |
|---|---|---|
| `image: local/opencode:2.0.7` | `Deployment/opencode` 내 `local/opencode:2.0.7-cli` | OpenCode 이미지 기본 버전 2.0.7 유지 |
| `/home/toss:/home/toss` | hostPath `/home/toss` | 동일 경로 유지 |
| `./config:/root/.config/opencode` | hostPath `/opt/opencode/config` | 기존 모델/프로바이더 설정 유지 |
| `./data/share:/root/.local/share/opencode` | hostPath `/opt/opencode/data/share` | 기존 세션 데이터 유지 |
| `./data/cache:/root/.cache/opencode` | hostPath `/opt/opencode/data/cache` | 기존 캐시 유지 |
| `secrets/ollama_api_key` | Kubernetes Secret `ollama-api-key` | 기존 API 키 그대로 이관 |
| Docker Compose TUI PID1 | Deployment의 `tail -f /dev/null` + `kubectl exec -it` | 터미널 재접속 용이 |

`opencode` 명령어가 호스트에서 없거나 호스트 Python 3.9.25인 것은 정상입니다. OpenCode는 Docker 내부에 있었으며 새로운 K8s 이미지 안에서 실행됩니다. 호스트 Python 업그레이드는 불필요합니다.

## B. 원본 시스템 점검

이 명령어는 모두 **master1 호스트의 셸**에서 실행합니다.

```bash
kubectl cluster-info
kubectl get nodes -o wide
kubectl get node master1 --show-labels
kubectl get node master1 -o jsonpath='{.status.nodeInfo.containerRuntimeVersion}{"\n"}'
ls -l /opt/opencode/config/
ls -l /opt/opencode/data/share/
ls -l /opt/opencode/data/cache/
ls -ld /home/toss
ls -l /opt/opencode/secrets/ollama_api_key
```

**확인 포인트:** 실제 노드의 `kubernetes.io/hostname` 라벨이 `master1`인지, `kubectl` 인증이 가능한지, 저장 디렉터리가 있는지 확인합니다. 배포본은 노드 `master1`에 고정되며 해당 노드의 hostPath에 기존 데이터가 있다고 가정합니다. 네트워크 스토리지 기반 멀티노드 운영이나 PVC 전환은 이후 단계입니다.

## C. 전환 전 데이터 백업

```bash
cd /opt/opencode
umask 077
tar -czf /root/opencode-backup-$(date +%F-%H%M).tgz -C /opt \
  opencode/config opencode/data opencode/secrets
```

백업에는 API 인증정보가 포함되므로 반드시 접근권한을 제한하고 안전한 곳에 보관합니다. **기존 Docker OpenCode와 K8s OpenCode를 동일한 설정/세션 데이터에 동시 실행하지 마세요.** 기존 컨테이너는 `docker compose run`으로 생성된 이름이므로 `docker ps`로 실제 컨테이너를 확인한 뒤 백업 이후 종료해야 합니다. 이때 `down -v`나 데이터 삭제는 절대 수행하지 않습니다.

## D. 패키지 압축 해제 및 CLI-Anything 연결

패키지 파일 `opencode-k8s-https.zip`을 master1 서버로 안전하게 전송한 다음:

```bash
cd /opt/opencode
unzip opencode-k8s-https.zip
cd /opt/opencode/opencode-k8s-https
bash scripts/prepare-cli-anything.sh
ls -l /opt/opencode/config/commands/
```

스크립트는 공식 저장소 `https://github.com/HKUDS/CLI-Anything.git`를 `/opt/opencode/CLI-Anything`에 다운로드합니다. 공식 `opencode-commands/*.md` 및 `HARNESS.md`를 기존 전역 설정에 등록합니다. 모델이 HARNESS 파일을 놓치지 않도록 내부 경로를 `/root/.config/opencode/commands/HARNESS.md`로 교정합니다.

정상이라면 `cli-anything.md`, `cli-anything-list.md`, `cli-anything-refine.md`, `cli-anything-test.md`, `cli-anything-validate.md`, `HARNESS.md`, `https-session-dashboard.md` 등이 표시됩니다.

**주의:** OpenCode 2.0.7에서 만약 `commands/`를 인식하지 못한다면 버전 호환성 문제일 수 있습니다. 먼저 최신 안정판의 동작을 별도 테스트하고, 필요 시 `command/` 단수 디렉터리 경로를 복제해 시험합니다. 명령어를 두 경로에 동시에 등록하면 버전에 따라 중복 로드될 수 있으니 성공한 경로 하나만 유지합니다.

## E. 이미지 빌드 및 Kubernetes 런타임에 등록

```bash
cd /opt/opencode/opencode-k8s-https
bash scripts/build-images.sh
```

OpenCode 신규 이미지는 현재 `docker ps`에 표시된 `local/opencode:2.0.7`을 기반으로 빌드합니다. 기존 이미지를 삭제하지 마세요. 예상 이미지:
- `local/opencode:2.0.7-cli`
- `local/https-session-dashboard:0.1.0`

**중요:** 호스트 Docker 데몬에서 빌드한 이미지는 K8s 컨테이너 런타임이 containerd인 경우 자동 공유되지 않습니다. 확인 후 containerd 환경이면:

```bash
bash scripts/load-containerd.sh
ctr -n k8s.io images ls | grep -E 'opencode|https-session-dashboard'
```

Kubernetes CRI가 CRI-O라면 이 스크립트를 사용하지 말고 내부 이미지 레지스트리를 구축해 두 이미지를 push한 후 배포 매니페스트 이미지 및 풀 정책을 수정하세요. 여러 노드에 걸쳐 운영할 때도 레지스트리 사용이 필수적으로 권장됩니다.

## F. 네임스페이스, Secret 및 Deployment 적용

백업과 Docker 컨테이너 종료를 마친 뒤:

```bash
cd /opt/opencode/opencode-k8s-https
bash scripts/deploy.sh
kubectl -n opencode get deployment,pod,service -o wide
```

`deploy.sh`에서 수행하는 내용:
1. `Namespace/opencode` 생성
2. 기존 `ollama_api_key`를 Secret으로 생성 (말단 개행문자 제거)
3. 업로드용 Bearer 토큰 신규 생성 및 Secret 등록
4. `/opt/opencode/dashboard-data` 생성(UID 10001)
5. `Deployment/opencode`, `Deployment/https-dashboard`, `Service/https-dashboard` 생성
6. 롤아웃 상태 확인

설정 파일 속 API 키 값을 예시 문서 또는 Git 저장소에 복사하지 마세요. K8s Secret은 기본적으로 암호화된 비밀 저장소와 동일하지 않으므로 etcd 암호화, 백업 보안, 읽기 권한 RBAC도 확인해야 합니다.

## G. OpenCode 실행 및 CLI-Anything 동작 확인

```bash
kubectl -n opencode exec -it deployment/opencode -- /bin/sh
whoami
pwd
opencode --version
python3 --version
ls -lh /root/.config/opencode/commands
opencode
```

Pod 안에서는 `root`, `/home/toss`가 보이는 것이 예상됩니다. 대시보드의 소스코드는 Pod 내 `/workspace/https-monitor/dashboard`, 매니페스트는 `/workspace/https-monitor/k8s`에서도 접근할 수 있습니다. OpenCode 화면에서 다음을 시험합니다.

```text
/cli-anything-list
/https-session-dashboard 대시보드의 최근 이벤트 테이블에 필터를 추가해줘
```

소스 자체를 CLI로 만들기 위해 CLI-Anything을 사용하려면 대상 소스코드가 필요합니다. 예를 들어 `/home/toss/myproject`가 실제 코드 저장소라면:

```text
/cli-anything /home/toss/myproject
```

이 명령어는 AI에게 CLI 코드 생성 작업을 지시합니다. 기설치 CLI 실행파일이나 네트워크 센서가 자동 생성되는 것은 아닙니다. 생성된 CLI를 설치·실행하기 전에 코드 검토와 테스트를 수행하세요.

## H. HTTPS 대시보드 접속

OpenCode와 웹 대시보드는 서로 다른 Deployment입니다. `opencode`는 CLI 프로그램이며 브라우저 화면이 아닙니다. 브라우저 접근용 Service는 `https-dashboard`만 구성되어 있습니다.

master1에서 포트포워드:

```bash
kubectl -n opencode port-forward svc/https-dashboard 18080:8080 --address 127.0.0.1
```

같은 master1 브라우저에서 `http://127.0.0.1:18080`을 열 수 있습니다. 다른 Windows 또는 Linux PC에서는 SSH 로컬포워딩을 추가합니다.

```bash
ssh -L 18080:127.0.0.1:18080 <ssh-user>@master1
```

이후 PC 브라우저에서 `http://127.0.0.1:18080`으로 접속합니다. 설치 초기에는 수집 이벤트가 없어 모든 통계가 0 또는 비어 있는 것이 정상입니다.

## I. 샘플 이벤트 넣고 UI 확인

master1에서 포트포워드를 켜 둔 상태로 다른 터미널에서:

```bash
cd /opt/opencode/opencode-k8s-https
python3 scripts/send-demo.py
```

위 프로그램은 문서 예시 IP 대역 `192.0.2.0/24`, `198.51.100.0/24`, `203.0.113.0/24`만 사용해 **가상의 이벤트 85건**을 생성합니다. 실제 HTTPS 트래픽의 측정 결과가 아닙니다. 편집 가능한 기본 구성도는 패키지 내 `docs/architecture.drawio`에 포함되어 있습니다. 브라우저에서 다음을 확인합니다.

- 최근 5분/15분/1시간/3시간/24시간 집계 전환
- 이벤트 총합, 성공 건수, 차단·오류 건수, 바이트 합계
- 출발지에서 목적지 HTTPS 포트로 이어지는 흐름도
- 분당 이벤트 추세와 최신 이벤트 50건
- `Draw.io 내보내기`로 현재 집계된 흐름을 편집 가능한 `.drawio` 형식으로 저장

정규화된 데이터 업로드 API는 `POST /api/events`입니다. `Authorization: Bearer <token>` 및 `application/json`을 요구합니다. 제공 `examples/event.json`을 참고하세요. 이 버전에는 실제 수집기는 포함되지 않았습니다.

## J. CLI-Hub에서 Draw.io가 필요한 경우

CLI-Anything 공식 OpenCode 연동 자체에는 CLI-Hub 설치가 불필요합니다. 별도로 Draw.io CLI 기능을 사용하려면 Python 3.10 이상 컨테이너와 `cli-anything-hub` 패키지가 필요합니다.

```bash
kubectl -n opencode exec -it deploy/opencode -- /bin/sh
mkdir -p /home/toss/.venvs
python3 -m venv /home/toss/.venvs/cli-hub
/home/toss/.venvs/cli-hub/bin/pip install cli-anything-hub
/home/toss/.venvs/cli-hub/bin/cli-hub search diagram
/home/toss/.venvs/cli-hub/bin/cli-hub info drawio
```

`cli-hub install drawio` 이후에도 **Draw.io 데스크톱 앱, GUI 또는 가상 디스플레이 실행 조건**이 필요할 수 있습니다. 현재 OpenCode는 Alpine 기반이므로 Draw.io 데스크톱용 의존성은 별도 Debian/Ubuntu 기반 렌더링 Pod에서 준비하는 편이 더 안전합니다. 이 시범 대시보드는 그러한 GUI 의존성 없이 Python이 직접 유효한 Draw.io XML을 출력합니다.

## K. 실제 HTTPS 세션 모니터링 구축 전 추가 결정 사항

### 1. 센서 결정

- 방화벽 FortiGate Traffic/Security 로그: 출발지, 목적지, 포트, 액션, 바이트, 시간, 세션 ID를 제공할 수 있습니다. 실제 필드와 의미는 펌웨어·설정·로그 종류에 따라 확인해야 합니다.
- Nginx / Apache 접근로그: HTTP 요청 건수와 응답코드 집계에 적합하지만, **TCP/TLS 동시 연결 세션 수와는 다릅니다.**
- L4/L7 Load Balancer / TLS 종단 프록시: TLS 협상 오류·연결 이벤트가 수집 가능한지 제품별 확인이 필요합니다.
- NetFlow/IPFIX: TCP/UDP 흐름과 바이트는 확인할 수 있으나 HTTPS 내부 URL, HTTP 응답코드는 일반적으로 볼 수 없습니다.

### 2. 실시간 운영 기능

- Collector/Parser/Queue: 샘플 로그를 받아 장비별 데이터 구조를 정규화하고, 중복·전송 실패·재전송을 처리해야 합니다.
- '동시 접속 세션' 계산을 원한다면 별도의 세션 시작/종료 이벤트 또는 상태 테이블과 timeout 정책이 필요합니다.
- 실서비스용 권한 관리: 대시보드 조회자 인증, 데이터 수집기의 인증/암호화, 접속 IP 제한, 감사로그, 데이터 보존정책.
- 저장/검색 성능: 현재 SQLite는 테스트 규모, 추후 Prometheus/OpenSearch/ClickHouse 등 요구에 따라 교체 여부 검토.
- 운영 및 배포: 이미지 내부 레지스트리, PVC, 백업, 알림/SLA, 모니터링 Pod의 리소스 제한.

### 3. 실제 연동에 필요한 최소 정보

민감정보를 제거한 로그 5~10건(가능하면 정상 연결·차단·종료 로그 모두), 사용 장비 또는 제품/버전, 수집 방식(Syslog/HTTP/API), 원하는 UI 측정 지표(동시 세션인지, 초당 연결/분당 이벤트인지)를 확인해야 실제 수집기를 제작할 수 있습니다.

## L. 장애 점검 및 복구

```bash
kubectl -n opencode get pod,svc -o wide
kubectl -n opencode describe pod -l app=opencode
kubectl -n opencode describe pod -l app=https-dashboard
kubectl -n opencode logs deployment/https-dashboard --tail=100
kubectl -n opencode exec deployment/opencode -- ls -l /root/.config/opencode/commands
kubectl -n opencode get secrets
```

- `ErrImageNeverPull`: `master1`의 실제 K8s 런타임에 두 이미지가 없습니다. containerd import 또는 레지스트리 방식으로 해결합니다.
- `Pending`: `master1` 라벨/taint, 자원 및 PVC/볼륨 접근을 점검합니다.
- API 인증 실패: Secret에 개행문자가 섞이지 않았는지, 토큰을 올바른 곳에서 읽는지 점검합니다.
- 대시보드 DB 쓰기 실패: `/opt/opencode/dashboard-data` 소유권 10001과 호스트 SELinux 보안 설정을 확인합니다.
- 세션 데이터 미표시: 기존 Docker 컨테이너를 종료했는지와 `/opt/opencode/data/share` 매핑이 동일한지 확인합니다.

**롤백:** `kubectl -n opencode scale deploy/opencode deploy/https-dashboard --replicas=0`으로 쓰기를 중지한 뒤 데이터 상태를 확인하고, 이전 Docker Compose를 다시 실행합니다. K8s 리소스 삭제 전 백업 여부를 재확인하세요.

### 검증 범위와 주의

제공 패키지 Python 단위시험, HTTP 요청 인증/수집·집계·Draw.io XML 동작 확인, YAML 구문 검사를 수행했습니다. **실제 `master1` Kubernetes API·CRI·Nutanix 인프라에서 설치 검증을 완료했다는 뜻은 아닙니다.** 신규 설치 전 백업과 점검을 반드시 수행해야 합니다.
