# v1 Hubble Collector HTTP 401 Unauthorized 수정 안내

## 원인

기존 `install.sh`는 `openssl rand -hex 32 > secrets/dashboard_ingest_token`으로 토큰을 생성해 끝에 `\n`이 붙습니다. `dashboard/server.py`는 환경변수 값을 그대로 비교했고, `collector/collector.py`는 `.strip()`으로 끝의 개행을 제거했습니다. 따라서 동일 Secret을 주입해도 Bearer 인증 문자열이 달라져 이벤트 POST와 heartbeat에서 HTTP 401이 발생했습니다.

## 운영 중 복구 (전체 삭제/재설치 불필요)

새 ZIP에서 `scripts/repair-ingest-auth.sh` 파일만 현재 설치 경로 `/opt/opencode/scripts/`에 복사하거나, 전체 ZIP을 `/opt/opencode`에 덮어쓴 다음 실행합니다.

```bash
cd /opt/opencode
bash scripts/repair-ingest-auth.sh
bash scripts/check.sh
```

수정 스크립트는 토큰의 CR/LF 제거, Secret 재적용, Dashboard와 Collector의 순차적 롤아웃만 처리합니다. 기존 DB, Hubble, Grafana, Cloudflare, NodePort를 건드리지 않습니다.

### 정상 기대값

```text
Hubble Relay connected: hubble-relay.kube-system.svc.cluster.local:80
collector: {"state":"connected", ...}
opencode_hubble_collector_connected 1
```

이벤트 카운트는 실제 관측 이벤트가 들어와야 0에서 증가합니다. 초기 안정화에 잠시 시간이 필요합니다. 외부 Hubble Relay가 접속되지 않는다면 Collector 로그에 별도 오류가 표시됩니다.

## 재설치 대응

수정 설치본에서는 토큰을 개행 없이 생성하고 기존 토큰 복원 시 CR/LF를 정규화합니다. Dashboard 코드에도 `.strip()`을 적용하여 같은 문제가 재발하지 않도록 수정했습니다.

Grafana NodePort 31300 변경은 **포함하지 않았습니다**. 현재 v1 기준대로 Grafana는 ClusterIP입니다.
