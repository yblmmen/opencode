# Kubernetes Hubble TCP Lifecycle 분석기 v1.1 운영 매뉴얼

## 1. 목표

특정 IPv4/IPv6 주소를 입력해 최근 Hubble TCP Flow를 검색하고, **IP:Port 쌍(4-tuple)** 기준으로 연결을 선택하면 시간순 SYN, SYN/ACK, ACK, FIN, RST, 정책 Drop 이벤트를 표시한다. TLS 협상 단계나 정확한 TCP 시퀀스 번호 분석은 Hubble만으로 불가능하며 **PCAP/tshark**로 분석한다.

기존 Kubernetes 네임스페이스 `opencode`, 대시보드 NodePort `31800`, Cloudflare 주소 `https://dash.innerinfo.org`, 기존 Cilium Hubble Relay를 유지한다. Grafana Service는 이전 구성(ClusterIP)을 변경하지 않는다.

## 2. 운영 중 업그레이드 (권장)

설치본을 **/root/opencode-v1**에 풀어 놓고 아래 1줄을 실행한다.

```bash
cd /root
unzip -oq /root/opencode-hubble-v1.1-tcp.zip -d /root
bash /root/opencode-v1/scripts/upgrade-tcp.sh
```

- 백업은 `/root/opencode-backups/tcp-before-v1.1-YYYYmmdd-HHMMSS.tgz` 생성.
- 기존 DB·토큰·Prometheus·Grafana·OpenCode·Cloudflared는 보존.
- `https-dashboard`와 `hubble-collector` **두 Deployment만** 이미지 교체.
- 이미지는 `local/https-dashboard:v1.1`, `local/hubble-collector:v1.1`.
- Dashboard SQLite `events` 테이블에 플래그·밀리초 시각·Drop 사유·관측 노드 컬럼이 자동 추가됨. **기존 이벤트에는 TCP 플래그가 채워지지 않는다.**
- UI 접속 주소는 바뀌지 않음: `https://dash.innerinfo.org` (외부 DNS 정상일 때).

## 3. IP 검색 순서

1. Dashboard 상단 아래 **IP별 TCP 연결 수명주기** 영역으로 이동.
2. `검색 IP` 입력: 예 `10.0.0.219`; 선택적으로 상대 IP·포트·기간 지정.
3. **연결 검색** 버튼 클릭.
4. 왼쪽의 `10.0.0.219:출발포트 → 상대IP:목적포트` 연결 선택.
5. 오른쪽에서 **TCP 3-way, 4-way 단계**, 상세 패킷 방향 및 시간, Drop/RST/SYN 반복 진단 확인.
6. 화면은 검색 중일 때 10초마다 갱신. 실제 Hubble 수집 프로세스는 계속 실행.

## 4. CLI 진단 및 Hubble 원본 확인

```bash
cd /opt/opencode
bash scripts/test-tcp.sh 10.0.0.219
TCP_TEST_IP=10.0.0.219 bash scripts/check.sh
kubectl -n opencode logs deploy/hubble-collector --since=5m | tail -40
```

Hubble 자체에서 해당 IP 원본을 확인하려면 Hubble CLI가 설치된 위치에서:

```bash
hubble observe --server hubble-relay.kube-system.svc.cluster.local:80 \
  --from-ip 10.0.0.219 --follow -o json
```

대상 IP가 목적지인 이벤트도 확인하려면 `--to-ip`를 추가로 조회하거나, UI의 양방향 IP 검색을 사용한다. **Hubble CLI는 클러스터에 따라 `hubble` 명령이 설치되지 않았을 수 있으니 Collector 로그와 CLI의 `--help` 출력도 확인한다.**

## 5. 오류 표시 해석

| 화면 | 확인한 사실 | 추가 확인 |
|---|---|---|
| SYN → SYN/ACK → ACK 모두 관측 | 3-way 구성 요소 관측 | ACK/SEQ 번호까지 검증한 것은 아님 |
| 반복 SYN, SYN/ACK 미관측 | SYN 반복 / 응답 관측되지 않음 | 서버 응답, 방화벽 Drop, 패킷 캡처 지점 |
| Hubble DROPPED | 정책/스택 등에서 차단 이벤트 관측 | Drop reason, node_name, observation_point |
| RST | 해당 방향에서 RST 패킷 관측 | 서버/클라이언트 소켓 로그, 애플리케이션 종료 정책 |
| 한 방향 FIN | 한 방향 종료 관측 | 반대 방향 FIN 및 ACK 별도 확인 |
| 양방향 FIN + ACK | 종료 단계의 플래그 관측 | 순서·seq/ack 확인은 PCAP 필요 |
| ACK/SYN이 보이지 않음 | 수집된 Hubble 이벤트에 없음 | 실패를 단정하지 말 것 |

`Hubble`은 패킷 모두를 빠짐없이 수집하는 시스템이 아니다. Hubble의 동일 흐름이 서로 다른 관측 지점에서 중복 이벤트로 나타날 수 있다. 본 v1.1의 연결 분류는 4-tuple과 20분 유휴 구간·새 SYN 이벤트를 사용하므로 **NAT, 포트 재사용 및 오래 지속되는 연결에서 연결 구간 분리에 오차가 존재한다.**

## 6. HTTPS/TLS 요청을 정확히 진단하려면

현재 Cloudflare 외부 HTTPS는 Cloudflare Edge에서 TLS가 종료되므로, NodePort `31800`에 전달된 **HTTP 트래픽만으로 TLS ClientHello/ServerHello를 볼 수 없다**. TCP 플래그는 Hubble로, 실제 패킷·TCP 번호·재전송·TLS 협상은 클라이언트 또는 TLS가 실제로 보이는 구간에서 PCAP을 수집하여 `scripts/https-lifecycle.sh`로 분석한다.

```bash
bash /opt/opencode/scripts/https-lifecycle.sh \
  /home/toss/captures/session.pcapng 0 --out /home/toss/captures/session.html
```

기존 CLI 사용 시 인자는 `scripts/https-lifecycle.sh` 내부 도움말을 우선 확인한다.

## 7. 복구 및 완전 재설치

### 새 TCP 기능만 이전 이미지로 되돌리기

```bash
bash /opt/opencode/scripts/rollback-tcp.sh
```

단, 기존 `:v1` 이미지가 `master1`의 containerd에 남아 있어야 한다.

### 전체 초기화 후 v1.1 재설치 (기존 namespace/data 삭제)

```bash
cd /root
unzip -oq /root/opencode-hubble-v1.1-tcp.zip -d /root
bash /root/opencode-v1/scripts/reinstall.sh
```

**완전 초기화는 `/opt/opencode`와 `opencode` 네임스페이스를 삭제한다.** `RESET V1` 확인을 요구하고 `/root/opencode-backups/`에 백업을 만든다. `/home/toss`, 기존 Cilium/Hubble, Cloudflare 외부 도메인 설정은 삭제하지 않는다. 초기화 스크립트는 `scripts/reset.sh`에 계속 포함되어 있다.

## 8. 업그레이드 검증

```bash
kubectl -n opencode get pods,svc
kubectl -n opencode logs deploy/hubble-collector --since=3m
curl -sS 'http://192.168.9.221:31800/api/tcp/connections?ip=10.0.0.219&minutes=60'
```

**주의:** v1.1 이전 DB의 이벤트는 플래그 메타데이터가 없으므로 기존 데이터만 검색하면 `미관측`으로 표시된다. 새로운 TCP 연결을 발생시켜 검증한다.
