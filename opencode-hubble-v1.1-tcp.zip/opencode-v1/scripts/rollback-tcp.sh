#!/usr/bin/env bash
# Roll back image only; DB schema added in v1.1 is backwards compatible.
set -Eeuo pipefail
kubectl -n opencode set image deployment/https-dashboard dashboard=local/https-dashboard:v1
kubectl -n opencode set image deployment/hubble-collector collector=local/hubble-collector:v1
kubectl -n opencode rollout status deployment/https-dashboard --timeout=240s
kubectl -n opencode rollout status deployment/hubble-collector --timeout=240s
printf '기존 이미지 롤백 완료. 영구 복원을 원하면 백업된 v1 설치 소스도 복원하세요.\n'
