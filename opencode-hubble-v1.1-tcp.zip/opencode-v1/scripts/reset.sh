#!/usr/bin/env bash
# v1 full reset. Run from an extracted package OUTSIDE /opt/opencode.
set -Eeuo pipefail
TARGET=/opt/opencode
BACKUPS=/root/opencode-backups
if [[ $(id -u) -ne 0 ]]; then echo 'root로 실행하세요.' >&2; exit 1; fi
if [[ "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)" == "$TARGET" ]]; then
  echo '오류: 초기화 스크립트는 /opt/opencode 밖(/root/opencode-v1)에서 실행해야 합니다.' >&2; exit 1
fi
command -v kubectl >/dev/null || { echo 'kubectl이 필요합니다.' >&2; exit 1; }
echo '완전 초기화 대상: Kubernetes namespace opencode 전체 / 기존 /opt/opencode'
echo '보존: /home/toss, kube-system(Cilium/Hubble), Cloudflare 웹 경로, GitHub 원격 저장소'
echo "백업 경로: ${BACKUPS}"
read -r -p '실행하려면 RESET V1 입력: ' RESPONSE
[[ "$RESPONSE" == 'RESET V1' ]] || { echo '취소됨'; exit 1; }
# Stop only the prior standalone OpenCode container, if present.
if command -v docker >/dev/null; then
  mapfile -t EXISTING < <(docker ps --format '{{.ID}} {{.Image}}' | awk '$2 ~ /^local\/opencode:/ {print $1}')
  if ((${#EXISTING[@]})); then
    printf '이전 Docker OpenCode 중지: %s\n' "${EXISTING[*]}"
    docker stop "${EXISTING[@]}"
    docker rm "${EXISTING[@]}" || true
  fi
fi
if kubectl get ns opencode >/dev/null 2>&1; then
  echo '[1/4] 이전 Deployment 종료 및 데이터 쓰기 중단'
  for name in $(kubectl -n opencode get deploy -o name 2>/dev/null || true); do
    kubectl -n opencode scale "$name" --replicas=0 || true
  done
  for i in $(seq 1 75); do
    RUNNING=$(kubectl -n opencode get pods -o jsonpath='{.items[*].metadata.name}' 2>/dev/null || true)
    [[ -z "$RUNNING" ]] && break
    sleep 2
  done
  [[ -z "$(kubectl -n opencode get pods -o jsonpath='{.items[*].metadata.name}' 2>/dev/null || true)" ]] || {
    echo '기존 Pod 종료가 끝나지 않아 백업을 중단합니다.' >&2; exit 1;
  }
fi
mkdir -p "$BACKUPS"
if [[ -d "$TARGET" ]]; then
  echo '[2/4] 기존 디렉터리 전체 백업'
  STAMP=$(date +%Y%m%d-%H%M%S)
  ARCHIVE="$BACKUPS/opencode-before-v1-$STAMP.tar.gz"
  umask 077
  tar -C /opt -czf "$ARCHIVE" opencode
  tar -tzf "$ARCHIVE" >/dev/null
  echo "백업 검증 완료: $ARCHIVE"
fi
if kubectl get ns opencode >/dev/null 2>&1; then
  echo '[3/4] 이전 Kubernetes 네임스페이스 전체 제거'
  kubectl delete ns opencode --wait=true --timeout=300s
fi
echo '[4/4] 이전 프로젝트 디렉터리 제거'
rm -rf -- "$TARGET"
# Cleanup ONLY images from previous OpenCode monitoring packages, not Cilium/Hubble or generic images.
if command -v docker >/dev/null; then
  while IFS= read -r img; do
    [[ -n "$img" ]] && docker image rm "$img" >/dev/null 2>&1 || true
  done < <(docker images --format '{{.Repository}}:{{.Tag}}' 2>/dev/null | grep -E '^local/(opencode|https-dashboard|hubble-collector|lifecycle-grafana):' || true)
fi
if command -v ctr >/dev/null; then
  while IFS= read -r img; do
    [[ -n "$img" ]] && ctr -n k8s.io images rm "$img" >/dev/null 2>&1 || true
  done < <(ctr -n k8s.io images ls -q 2>/dev/null | grep -E '^local/(opencode|https-dashboard|hubble-collector|lifecycle-grafana):' || true)
fi
echo '완료: 새 v1 배포 파일을 /opt/opencode에 복사한 후 install.sh를 실행하세요.'
