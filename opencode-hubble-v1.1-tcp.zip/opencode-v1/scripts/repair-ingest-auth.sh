#!/usr/bin/env bash
# Fix v1 initial-install 401 caused by CR/LF in dashboard-ingest token.
# Keeps existing token; does not recreate DB, namespace, or Pods other than target rollouts.
set -Eeuo pipefail
ROOT=/opt/opencode
NAMESPACE=opencode
TOKEN_FILE="$ROOT/secrets/dashboard_ingest_token"
[[ -f "$TOKEN_FILE" ]] || { echo "토큰 파일 없음: $TOKEN_FILE" >&2; exit 1; }
command -v kubectl >/dev/null || { echo "kubectl을 찾지 못했습니다" >&2; exit 1; }
[[ $(id -u) -eq 0 ]] || { echo "root 권한으로 실행하십시오" >&2; exit 1; }

# Capture the canonical (newline-free) token without printing it.
umask 077
TOKEN="$(tr -d '\r\n' < "$TOKEN_FILE")"
[[ -n "$TOKEN" ]] || { echo '토큰 값이 비어 있습니다' >&2; exit 1; }
printf '%s' "$TOKEN" > "$TOKEN_FILE"
chmod 600 "$TOKEN_FILE"
unset TOKEN

kubectl -n "$NAMESPACE" create secret generic dashboard-ingest \
  --from-file="token=$TOKEN_FILE" --dry-run=client -o yaml | kubectl apply -f -
kubectl -n "$NAMESPACE" rollout restart deployment/https-dashboard deployment/hubble-collector
kubectl -n "$NAMESPACE" rollout status deployment/https-dashboard --timeout=180s
kubectl -n "$NAMESPACE" rollout status deployment/hubble-collector --timeout=180s
printf '\nCollector 최근 로그 (토큰값은 표시하지 않음):\n'
kubectl -n "$NAMESPACE" logs deployment/hubble-collector --tail=25
printf '\n검증: bash /opt/opencode/scripts/check.sh\n'
