#!/usr/bin/env bash
# Non-destructive v1 -> v1.1 TCP lifecycle update. Existing data and services preserved.
set -Eeuo pipefail
SRC=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)
DST=/opt/opencode
[[ $(id -u) == 0 ]] || { echo 'root 계정으로 실행하십시오' >&2; exit 1; }
[[ "$SRC" != "$DST" ]] || { echo '업그레이드 패키지는 /root/opencode-v1 등 별도 경로에 둡니다' >&2; exit 1; }
for cmd in kubectl docker ctr tar; do command -v "$cmd" >/dev/null || { echo "$cmd 명령 없음" >&2; exit 1; }; done
kubectl -n opencode get deploy https-dashboard hubble-collector >/dev/null
[[ -f "$DST/dashboard/server.py" && -f "$DST/collector/collector.py" ]] || { echo '기존 설치 경로를 찾을 수 없습니다' >&2; exit 1; }
mkdir -p /root/opencode-backups
STAMP=$(date +%Y%m%d-%H%M%S)
tar -C "$DST" -czf "/root/opencode-backups/tcp-before-v1.1-$STAMP.tgz" dashboard collector k8s/20-dashboard.yaml k8s/25-hubble-collector.yaml scripts/install.sh
for f in dashboard/server.py dashboard/main.js dashboard/index.html dashboard/tcp.js dashboard/tcp_analysis.py collector/collector.py k8s/20-dashboard.yaml k8s/25-hubble-collector.yaml scripts/install.sh scripts/check.sh; do
  install -D -m 0644 "$SRC/$f" "$DST/$f"
done
install -D -m 0755 "$SRC/scripts/upgrade-tcp.sh" "$DST/scripts/upgrade-tcp.sh"
install -D -m 0755 "$SRC/scripts/rollback-tcp.sh" "$DST/scripts/rollback-tcp.sh"
echo '[1/4] 대시보드/Collector v1.1 이미지 빌드'
cd "$DST"
docker build -f Dockerfile.dashboard -t local/https-dashboard:v1.1 .
docker build -f Dockerfile.collector -t local/hubble-collector:v1.1 .
echo '[2/4] master1 containerd 이미지 등록'
for img in local/https-dashboard:v1.1 local/hubble-collector:v1.1; do docker save "$img" | ctr -n k8s.io images import -; done
echo '[3/4] 기존 배포의 이미지 2개만 교체'
kubectl -n opencode set image deployment/https-dashboard dashboard=local/https-dashboard:v1.1
kubectl -n opencode rollout status deployment/https-dashboard --timeout=240s
kubectl -n opencode set image deployment/hubble-collector collector=local/hubble-collector:v1.1
kubectl -n opencode rollout status deployment/hubble-collector --timeout=240s
echo '[4/4] API 확인'
kubectl -n opencode get pods,svc -o wide
NODE_IP=$(kubectl get node master1 -o jsonpath='{.status.addresses[?(@.type=="InternalIP")].address}')
curl -fsS --max-time 15 "http://${NODE_IP}:31800/tcp.js" >/dev/null
echo 'TCP 검색 기능 설치됨: https://dash.innerinfo.org'
echo "백업: /root/opencode-backups/tcp-before-v1.1-$STAMP.tgz"
echo '서비스 포트/Cloudflare 변경 없음. 검색 기능은 업그레이드 이후 수집된 이벤트의 플래그부터 표시됩니다.'
