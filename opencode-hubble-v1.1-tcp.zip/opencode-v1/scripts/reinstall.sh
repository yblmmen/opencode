#!/usr/bin/env bash
# One-entry fully clean reinstall. Run from /root/opencode-v1 (NOT /opt/opencode).
set -Eeuo pipefail
STAGING=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)
[[ "$STAGING" != /opt/opencode ]] || { echo 'v1 staging package must be OUTSIDE /opt/opencode.' >&2; exit 1; }
[[ $(id -u) -eq 0 ]] || { echo 'root 권한 필요' >&2; exit 1; }
cd /root
bash "$STAGING/scripts/reset.sh"
mkdir -p /opt/opencode
cp -a "$STAGING/." /opt/opencode/
cd /opt/opencode
bash scripts/install.sh
bash scripts/install-cloudflare.sh
bash scripts/check.sh
printf '\n새 v1 설치 완료. Cloudflare Published Route는 dash.innerinfo.org -> http://192.168.9.221:31800 으로 유지하세요.\n'
