# OpenCode · Hubble Network Flow Monitor v1.1 — TCP Lifecycle Explorer

**기존에 정상 운영 중인 v1 구성 유지**, IP 검색과 연결별 SYN/SYN-ACK/ACK/FIN/RST 수명주기 표시만 확장한 업데이트입니다.

- Kubernetes: `opencode` namespace, `master1` containerd
- Dashboard: `https://dash.innerinfo.org` → Cloudflare → `192.168.9.221:31800` → Pod 8080
- Hubble Relay: 기존 Cilium 설치 사용, Collector 자동 수집
- 기존 OpenCode/CLI-Anything, Grafana/Prometheus 유지
- TCP 검색: `/api/tcp/connections?ip=10.0.0.219&minutes=60`, 개별 연결 `/api/tcp/lifecycle?ip=...&minutes=60&anchor_id=...`
- 데이터: Hubble TCP 플래그, 정책 Drop 및 관측 노드 표시 (완전한 패킷 캡처 아님)

## 실행 — 기존 시스템 업그레이드

```bash
cd /root
unzip -oq opencode-hubble-v1.1-tcp.zip -d /root
bash /root/opencode-v1/scripts/upgrade-tcp.sh
```

## 실행 — 전체 초기화·새 설치

```bash
bash /root/opencode-v1/scripts/reinstall.sh
```

위 명령은 기존 전체 환경을 삭제하므로, 운영 중인 시스템에서는 **업그레이드 방식을 먼저 권장**합니다. 백업 및 삭제 동작은 `scripts/reset.sh`에 정의되어 있습니다.

자세한 운영 가이드: [`docs/TCP_LIFECYCLE_KO.md`](docs/TCP_LIFECYCLE_KO.md), 전체 설치 가이드: [`docs/INSTALL_KO.md`](docs/INSTALL_KO.md).
