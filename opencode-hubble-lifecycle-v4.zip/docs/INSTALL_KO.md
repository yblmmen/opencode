# Kubernetes Hubble 실시간 모니터링 + TCP/TLS Lifecycle CLI 운영 매뉴얼 v4

## 1. 목적과 역할 구분

| 수집/표현 | 구성 요소 | 가능한 결과 | 불가능/주의 |
|---|---|---|---|
| 전체 Namespace 네트워크 흐름 | 기존 Cilium/Hubble Relay + Collector | 출발지/목적지, TCP/UDP, 포트, Verdict, 이벤트 수 | 동시 TCP 연결 건수, 실제 HTTPS 본문 |
| 실시간 서비스 관계도 | Grafana Node Graph + Infinity Data Source | 상위 IP/Namespace 간 연결 그래프 (최근 5분 관측 이벤트) | 물리 전체망 토폴로지 자동 추론 |
| 통계·시계열 | Prometheus + Grafana | 최근 5분 흐름/차단/Namespace 분포, Collector 연결 상태 | 개별 TLS 패킷 협상 분석 |
| 개별 연결 Packet Lifecycle | tshark + `scripts/lifecycle.py` | 실제 PCAP 내 SYN/SYN-ACK/ACK, ClientHello/ServerHello, 암호화 레코드, FIN/RST의 시간순 SVG/HTML | PCAP에 없는 패킷 복원, TLS 1.3 암호화 내부 메시지 복호화, UDP/QUIC 연결 분석 |

**관측 범위의 중요 제한:** 운영 중인 `dash.innerinfo.org`는 외부 HTTPS(TLS 종료: Cloudflare) → Tunnel → `http://192.168.9.221:31800`으로 전달됩니다. 노드의 Origin HTTP 패킷을 캡처한다고 외부 클라이언트↔Cloudflare TLS 1.3 handshake가 나타나지는 않습니다. 그 handshake를 분석할 때는 외부 PC의 Wireshark 캡처 파일을 사용하세요. 외부 연결이 HTTP/3/QUIC이면 TCP 3-way 단계 자체가 없으므로 TCP 전용 CLI가 해당 통신을 분석하지 않습니다.

## 2. 기존 서비스 업그레이드 — 권장

```bash
cd /opt/opencode
unzip -o /root/opencode-hubble-lifecycle-v4.zip -d /opt/opencode
bash scripts/upgrade-monitor.sh
kubectl -n opencode get deploy,svc,pods
kubectl -n opencode logs -f deploy/hubble-collector
```

사전 조건: `master1`, Docker, containerd, `ctr`, kubectl. `dashboard-ingest` Secret은 이미 설정되어 있어야 합니다. `hubble-relay` 실제 포트/네임스페이스를 확인하세요.

```bash
kubectl get svc -A | grep -i hubble-relay
# 실제 서비스가 kube-system/80이 아니면 아래 파일에서 HUBBLE_SERVER 수정
vi k8s/25-hubble-collector.yaml
```

설치 스크립트는 Dashboard/Collector/Grafana 이미지를 호스트 Docker에서 빌드한 뒤 **master1의** containerd로 등록하므로, Pod 배치는 `master1`로 고정했습니다. Cloudflare Pod는 기존대로 다른 노드에 있어도 됩니다.

## 3. 신규 설치

```bash
# 이미 /opt/opencode에 소스가 있다면 git clone 생략
mkdir -p /opt/opencode
cd /opt/opencode
unzip -o /root/opencode-hubble-lifecycle-v4.zip -d /opt/opencode
bash scripts/install.sh
bash scripts/install-cloudflare.sh
```

Cloudflare Zero Trust / `dash` Tunnel / Published application Route:

- Hostname: `dash.innerinfo.org`
- Service Type: **HTTP**
- Service URL: `http://192.168.9.221:31800`
- 공개 브라우저 URL: **`https://dash.innerinfo.org`**

현재 터널 설정과 NodePort를 재배포할 때에도 이 값으로 유지합니다. DNS 문제는 환경별 재귀 DNS 캐시와 권한 DNS를 나누어 확인해야 합니다.

## 4. Grafana (신규 제공)

```bash
kubectl -n opencode port-forward svc/lifecycle-grafana 13000:3000
# 접속 PC가 서버가 아니라면 SSH -L 13000:127.0.0.1:13000 master1 를 함께 이용
```

`http://127.0.0.1:13000`, 계정 `admin`, 비밀번호 확인: `cat /opt/opencode/secrets/grafana_admin_password` (비밀번호는 외부에 공유하지 마세요). Dashboards > OpenCode > **Kubernetes Hubble · Flow Events & Service Graph**.

- `Lifecycle-Prometheus`: Hubble Bridge로부터 15초마다 수집되는 `/metrics`를 표시.
- `Hubble-Flow-API` (Infinity plugin): Node Graph에 필요한 `nodes`/`edges`를 Dashboard API `/api/grafana/graph?minutes=5`에서 가져옴.
- 이미지 빌드 때 Infinity 플러그인을 설치하므로 Docker 빌드 호스트는 외부 Grafana Plugin 저장소에 접근할 수 있어야 함.
- Node Graph는 실제 Hubble에서 관측된 최근 5분 **이벤트 연결 관계**를 표시하며 활성 TCP 세션 추적은 아님.
- Grafana는 ClusterIP로만 노출됩니다. 외부 도메인은 기존 대시보드에만 연결됩니다.

```bash
kubectl -n opencode get pods -o wide
kubectl -n opencode get svc lifecycle-grafana lifecycle-prometheus https-dashboard
kubectl -n opencode logs deploy/lifecycle-grafana --tail=60
kubectl -n opencode logs deploy/lifecycle-prometheus --tail=60
```

## 5. 실제 HTTPS TCP/TLS 연결 Lifecycle 생성

**PCAP 데이터가 필요합니다.** 캡처 주체는 외부 Windows PC(Wireshark 저장) 또는 해당 TCP 트래픽이 관측되는 Linux 인터페이스입니다. 개인 PC에서 DNS까지 확인한 뒤 Wireshark로 `tcp port 443` 트래픽을 저장해 `/home/toss/captures/sample.pcapng`로 옮기십시오. 외부 HTTPS over TCP 테스트 예: `curl.exe --http1.1 https://dash.innerinfo.org/`.

OpenCode 컨테이너에서:

```bash
kubectl -n opencode exec deploy/opencode -- python3 /workspace/opencode-project/scripts/lifecycle.py /home/toss/captures/sample.pcapng --list
kubectl -n opencode exec deploy/opencode -- python3 /workspace/opencode-project/scripts/lifecycle.py /home/toss/captures/sample.pcapng 0 --out /home/toss/captures/sample-stream0.html
```

또는 master1에 `tshark` 설치 후 `python3 /opt/opencode/scripts/lifecycle.py /home/toss/captures/sample.pcapng 0`. 생성된 HTML을 로컬 브라우저로 열면 **별도의 Draw.io 파일/수동 내보내기 없이 실제 패킷 순서도**가 보입니다. CLI는 `--out ...svg`도 지원합니다.

시퀀스 단계의 정확성:

- TCP `SYN`, `SYN/ACK`, 세 번째 `ACK`: 패킷에 해당 플래그가 있을 때만 표기
- `TLS ClientHello`, `TLS ServerHello`: tshark가 실제 TLS 핸드셰이크 유형을 식별할 때만 표기
- TLS record type 23: TLS1.3에서는 암호화된 핸드셰이크일 수도 있으므로 **'암호화 TLS 레코드'** 로만 표기, HTTP 본문으로 확정하지 않음
- FIN/RST: 캡처된 플래그만 표기. 모든 단계가 잡히지 않으면 '미관측'으로 표시
- HTTP/3/QUIC 지원은 향후 별도 분석기 필요

### Zeek 도입은 언제 필요한가?

실시간으로 **TLS 버전·암호군·SNI·연결 상태 메타데이터**를 대규모 수집할 필요가 생기면 Zeek 센서 + 로그 저장소를 추가하는 2단계를 권장합니다. 현재 패키지에는 Zeek를 자동 설치하지 않습니다. 적절한 패킷 미러링/캡처 지점이 없으면 Zeek만 설치해도 TLS를 관측할 수 없기 때문입니다.

## 6. 운영 확인

```bash
bash scripts/check.sh
kubectl -n opencode logs -f deploy/hubble-collector
kubectl -n opencode port-forward svc/https-dashboard 18080:8080
# 다른 터미널에서
curl -s http://127.0.0.1:18080/api/summary?minutes=5
curl -s http://127.0.0.1:18080/metrics
curl -s http://127.0.0.1:18080/api/grafana/graph?minutes=5
```

수집기와 Relay가 정상인데 값이 0이라면 `FILTER_PORTS=''`, `FILTER_NAMESPACES=''` 기본값 확인 및 Hubble Relay의 실제 스트림 데이터/NetworkPolicy 확인이 우선입니다. 빈 이벤트는 자동으로 생성하거나 임의의 '세션'으로 추정하지 않습니다.

## 7. 초기화 및 재설치

```bash
bash scripts/reset.sh              # 네임스페이스 삭제, runtime 자동 백업 및 보관
bash scripts/reset.sh --wipe-data  # 추가 확인 후 runtime까지 백업·삭제
bash scripts/install.sh
bash scripts/install-cloudflare.sh
```

`reset.sh`는 `/root/opencode-backups/`에 OpenCode/Grafana/Prometheus/Dashboard runtime을 백업한 후 네임스페이스를 삭제합니다. `/opt/opencode`의 개발 소스와 Git 이력, `/home/toss`는 삭제하지 않습니다. `--wipe-data`는 **백업 후** 런타임 데이터만 삭제합니다.

## 8. GitHub 업로드

```bash
cd /opt/opencode
bash scripts/github-push.sh
```

저장소: `https://github.com/yblmmen/opencode.git`, 브랜치 `main`; 기존 Git 저장소를 새로 초기화하지 마세요. 이전에 노출된 GitHub/Cloudflare 인증 토큰은 운영용 새 값으로 회전하는 것이 좋습니다.

## 9. 참고문서

- https://docs.cilium.io/en/stable/observability/metrics/
- https://grafana.com/docs/grafana/latest/visualizations/panels-visualizations/visualizations/node-graph/
- https://grafana.com/docs/plugins/yesoreyeram-infinity-datasource/latest/advanced-features/node-graph/
- https://docs.zeek.org/en/current/reference/logs/ssl.html
- https://www.wireshark.org/docs/man-pages/tshark.html
