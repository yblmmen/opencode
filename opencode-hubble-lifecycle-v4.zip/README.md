# OpenCode + Hubble Collector + Grafana Node Graph + HTTPS Lifecycle CLI (v4)

운영 환경: `master1` · `/opt/opencode` · Kubernetes namespace `opencode` · Dashboard NodePort `31800` · 외부 `https://dash.innerinfo.org` · GitHub `yblmmen/opencode` (`main`).

**Draw.io 완전 제외.** 기존 Cilium/Hubble과 Cloudflare Tunnel은 유지하며, 다음 두 분석 방법을 제공합니다.

1. **자동 실시간 관측:** Hubble Relay → 수집기 → 기존 Dashboard(실시간 SVG 네트워크 관계도) + Prometheus → Grafana(Node Graph/통계). `hubble observe`를 손으로 반복 실행할 필요 없음.
2. **단일 HTTPS 연결 수명주기:** 실제 `pcap`/`pcapng`를 `tshark`로 해석하고 관측된 TCP 3-way, TLS ClientHello/ServerHello, TLS 암호화 레코드, FIN/RST를 **HTML/SVG 시퀀스 다이어그램**으로 생성. 캡처되지 않은 단계는 그리지 않음.

![구성도](docs/architecture.svg)

## 현재 운영 환경에 v4만 업데이트 (전체 재설치 없음)

```bash
cd /opt/opencode
unzip -o /root/opencode-hubble-lifecycle-v4.zip -d /opt/opencode
bash scripts/upgrade-monitor.sh
bash scripts/check.sh
kubectl -n opencode logs -f deploy/hubble-collector
```

> 업그레이드에서는 OpenCode의 이미지(tshark 탑재)를 갱신하지 않습니다. CLI 분석은 master1에 tshark 설치 후 `python3 scripts/lifecycle.py ...`로 실행하거나 최초 전체 설치로 OpenCode 이미지를 재빌드하세요.

## 신규 구축 (Docker 이미지 빌드 + K8s 설치)

```bash
# 이미 git clone 된 소스가 있는 경우 재-clone 불필요
cd /opt/opencode
unzip -o /root/opencode-hubble-lifecycle-v4.zip -d /opt/opencode
bash scripts/install.sh
bash scripts/install-cloudflare.sh
```

- `install.sh`: local/opencode:2.0.7-cli, Dashboard/Collector/Grafana 이미지 빌드, containerd import, Prometheus/Grafana/Collector/NodePort 배포
- `install-cloudflare.sh`: 기존 Tunnel Secret 재사용. Cloudflare 서비스: **HTTP** `http://192.168.9.221:31800` (공개 URL은 `https://dash.innerinfo.org`)
- **Grafana:** `kubectl -n opencode port-forward svc/lifecycle-grafana 13000:3000` 후 로컬 `http://127.0.0.1:13000` (SSH 접속이면 추가 터널 필요)
- **Grafana admin 암호:** `/opt/opencode/secrets/grafana_admin_password` (설치 시 랜덤 생성)

## HTTPS 연결 패킷 시퀀스 자동 생성

```bash
# PCAP을 /home/toss/captures/session.pcapng에 미리 복사한 뒤
kubectl -n opencode exec deploy/opencode -- tshark -v
kubectl -n opencode exec deploy/opencode -- python3 /workspace/opencode-project/scripts/lifecycle.py /home/toss/captures/session.pcapng --list
kubectl -n opencode exec deploy/opencode -- python3 /workspace/opencode-project/scripts/lifecycle.py /home/toss/captures/session.pcapng 0 --out /home/toss/captures/session-0.html
```

실제 PCAP이 없다면 다이어그램을 임의 생성하지 않습니다. **Cloudflare의 외부 HTTPS는 Cloudflare Edge에서 TLS가 종료되고, Cluster NodePort 31800은 HTTP Origin**이므로, `dash.innerinfo.org`의 *외부 HTTPS handshake*를 관측하려면 브라우저/클라이언트 쪽에서 PCAP을 캡처해야 합니다. Hubble Relay의 TCP 443 흐름만으로 TLS 내부 메시지까지 알 수 없습니다. HTTP/3(QUIC)는 본 TCP 분석 도구의 범위 밖입니다.

## 검증과 재설치

```bash
bash scripts/check.sh
bash scripts/reset.sh              # 데이터 보관·백업 후 네임스페이스 제거
bash scripts/reset.sh --wipe-data  # 확인 입력 + 백업 후 데이터 삭제
bash scripts/install.sh
bash scripts/install-cloudflare.sh
bash scripts/github-push.sh        # 기존 GitHub 저장소 main에 변경사항 Push
```

실제 Kubernetes 배포 및 이미지 풀은 사용자 클러스터에서 확인해야 합니다. 상세 [설치·운영 매뉴얼](docs/INSTALL_KO.md) 참고.
