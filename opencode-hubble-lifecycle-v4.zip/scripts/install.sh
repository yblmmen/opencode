#!/usr/bin/env bash
# OpenCode + CLI-Anything + Dashboard: master1 /opt/opencode fresh install or redeploy
set -Eeuo pipefail
ROOT=/opt/opencode
cd "$ROOT"
for bin in git docker kubectl ctr openssl; do
  command -v "$bin" >/dev/null || { echo "필수 명령어 없음: $bin" >&2; exit 1; }
done
[[ -f k8s/20-dashboard.yaml && -f Dockerfile.dashboard ]] || { echo '설치 파일을 /opt/opencode에 먼저 풀어주세요.' >&2; exit 1; }
kubectl get node master1 >/dev/null
RUNTIME="$(kubectl get node master1 -o jsonpath='{.status.nodeInfo.containerRuntimeVersion}')"
[[ "$RUNTIME" == containerd* ]] || { echo "지원하지 않는 런타임: $RUNTIME (containerd 필요)" >&2; exit 1; }
if docker ps --format '{{.Names}} {{.Image}}' | grep -Eq 'opencode-opencode-run|local/opencode:2\.0\.7([[:space:]]|$)'; then
  echo '기존 Docker OpenCode가 실행 중입니다. 세션 중복 기록을 피하기 위해 먼저 중지하세요.' >&2
  exit 1
fi
mkdir -p config/commands data/share data/cache secrets /home/toss
if [[ ! -s secrets/ollama_api_key ]]; then
  read -rs -p 'Ollama API Key: ' KEY; echo
  [[ -n "$KEY" ]] || { echo 'Ollama API Key가 필요합니다.' >&2; exit 1; }
  (umask 077; printf '%s' "$KEY" > secrets/ollama_api_key)
  unset KEY
fi
if [[ ! -s secrets/dashboard_ingest_token ]]; then
  (umask 077; openssl rand -hex 32 > secrets/dashboard_ingest_token)
fi
chmod 600 secrets/ollama_api_key secrets/dashboard_ingest_token
if [[ ! -f CLI-Anything/cli-anything-plugin/HARNESS.md ]]; then
  git clone --depth 1 https://github.com/HKUDS/CLI-Anything.git CLI-Anything
fi
# 소스 폴더 내부 별도 .git은 제거해서 한 GitHub 저장소에서 관리
if [[ -d CLI-Anything/.git ]]; then rm -rf CLI-Anything/.git; fi
shopt -s nullglob
cmds=(CLI-Anything/opencode-commands/*.md)
(( ${#cmds[@]} > 0 )) || { echo 'CLI-Anything OpenCode 명령 파일 없음' >&2; exit 1; }
cp "${cmds[@]}" config/commands/
cp CLI-Anything/cli-anything-plugin/HARNESS.md config/commands/
sed -i 's#\./HARNESS\.md#/root/.config/opencode/commands/HARNESS.md#g' config/commands/cli-anything*.md
cat > config/commands/https-lifecycle.md <<'EOF'
---
description: Analyze real HTTPS TCP/TLS lifecycle from a PCAP file using tshark
---
Use bash /workspace/opencode-project/scripts/https-lifecycle.sh <pcap-file> [tcp-stream-id]. Check /workspace/opencode-project/docs/INSTALL_KO.md. Report only observed handshake phases.
Work from observed Hubble L3/L4 flow events; do not present event count as live TCP/TLS session count.
User request: $ARGUMENTS
EOF
printf '
[1/4] Docker 이미지 빌드
'
docker build -f Dockerfile -t local/opencode:2.0.7-cli .
docker build -f Dockerfile.dashboard -t local/https-dashboard:0.4.0 .
docker build -f Dockerfile.collector -t local/hubble-collector:0.4.0 .
docker build -f Dockerfile.grafana -t local/lifecycle-grafana:0.4.0 .
printf '
[2/4] master1 containerd에 이미지 등록
'
docker save local/opencode:2.0.7-cli | ctr -n k8s.io images import -
docker save local/https-dashboard:0.4.0 | ctr -n k8s.io images import -
docker save local/hubble-collector:0.4.0 | ctr -n k8s.io images import -
docker save local/lifecycle-grafana:0.4.0 | ctr -n k8s.io images import -
install -d -m 0750 -o 10001 -g 10001 "$ROOT/dashboard-data"
install -d -m 0750 -o 65534 -g 65534 "$ROOT/prometheus-data"
install -d -m 0750 -o 472 -g 472 "$ROOT/grafana-data"
printf '
[3/4] 네임스페이스 및 인증 Secret 생성
'
kubectl apply -f k8s/00-namespace.yaml
kubectl -n opencode create secret generic ollama-api-key \
  --from-file=OLLAMA_API_KEY=secrets/ollama_api_key \
  --dry-run=client -o yaml | kubectl apply -f -
kubectl -n opencode create secret generic dashboard-ingest \
  --from-file=token=secrets/dashboard_ingest_token \
  --dry-run=client -o yaml | kubectl apply -f -
if [[ ! -s secrets/grafana_admin_password ]]; then
  (umask 077; openssl rand -base64 24 > secrets/grafana_admin_password)
fi
kubectl -n opencode create secret generic lifecycle-grafana-admin \
  --from-file=password=secrets/grafana_admin_password \
  --dry-run=client -o yaml | kubectl apply -f -
kubectl -n opencode create configmap lifecycle-grafana-dashboards \
  --from-file=dashboard.json=grafana/dashboard.json \
  --dry-run=client -o yaml | kubectl apply -f -
printf '\n[4/4] Deployment + NodePort 31800 + Grafana 배포\n' 
kubectl apply -f k8s/10-opencode.yaml -f k8s/20-dashboard.yaml
kubectl -n opencode rollout restart deployment/opencode deployment/https-dashboard
kubectl -n opencode rollout status deployment/opencode --timeout=180s
kubectl -n opencode rollout status deployment/https-dashboard --timeout=180s
kubectl apply -f k8s/25-hubble-collector.yaml
kubectl apply -f k8s/40-prometheus.yaml -f k8s/50-grafana.yaml
kubectl -n opencode rollout status deployment/hubble-collector --timeout=180s
kubectl -n opencode get svc https-dashboard
kubectl -n opencode get pods -o wide
kubectl -n opencode rollout status deploy/lifecycle-prometheus --timeout=180s
kubectl -n opencode rollout status deploy/lifecycle-grafana --timeout=180s
echo 'Grafana: kubectl -n opencode port-forward svc/lifecycle-grafana 13000:3000'
echo '설치 완료: kubectl -n opencode exec -it deploy/opencode -- opencode'
echo 'Cloudflare 설치: bash scripts/install-cloudflare.sh'
