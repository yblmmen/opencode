#!/usr/bin/env bash
# GitHub: yblmmen/opencode / main; no token embedded in remote URL.
set -Eeuo pipefail
cd /opt/opencode
[[ -d .git ]] || { echo '먼저 git clone으로 기존 yblmmen/opencode 저장소를 가져오세요.' >&2; exit 1; }
REPO=https://github.com/yblmmen/opencode.git
git config --global --replace-all credential.helper store
if git remote get-url origin >/dev/null 2>&1; then
  git remote set-url origin "$REPO"
else
  git remote add origin "$REPO"
fi
[[ "$(git branch --show-current)" == main ]] || { echo '현재 브랜치가 main이 아닙니다.' >&2; exit 1; }
git add -f -A
if ! git diff --cached --quiet; then
  git commit -m "OpenCode backup $(date +%F_%H-%M)"
else
  echo '변경사항 없음'
fi
git push -u origin main
