#!/usr/bin/env bash
# Safe initialization: keep /opt/opencode sources and Git; backup runtime first.
set -Eeuo pipefail
ROOT=/opt/opencode
cd "$ROOT"
MODE="${1:-}"
[[ "$MODE" == '' || "$MODE" == '--wipe-data' ]] || { echo 'Usage: bash scripts/reset.sh [--wipe-data]' >&2; exit 2; }
echo 'Namespace opencode will be removed. External Cloudflare route and GitHub repo are preserved.'
echo '/opt/opencode project files and /home/toss are preserved.'
[[ "$MODE" != '--wipe-data' ]] || echo 'WARNING: --wipe-data also clears local config, session DB, dashboard DB and secrets AFTER backup.'
read -rp 'Type RESET to continue: ' CONFIRM
[[ "$CONFIRM" == RESET ]] || exit 1
if [[ "$MODE" == '--wipe-data' ]]; then
  read -rp 'Type DELETE DATA to remove runtime after backup: ' CONFIRM2
  [[ "$CONFIRM2" == 'DELETE DATA' ]] || exit 1
fi
if kubectl get ns opencode >/dev/null 2>&1; then
  # Stop all writers before taking consistent SQLite backup.
  for name in opencode https-dashboard hubble-collector cloudflared lifecycle-prometheus lifecycle-grafana; do
    if kubectl -n opencode get deploy "$name" >/dev/null 2>&1; then
      kubectl -n opencode scale "deployment/$name" --replicas=0
    fi
  done
  for i in $(seq 1 60); do
    PODS="$(kubectl -n opencode get pods -o jsonpath='{.items[*].metadata.name}')"
    [[ -z "$PODS" ]] && break
    sleep 2
  done
  [[ -z "$(kubectl -n opencode get pods -o jsonpath='{.items[*].metadata.name}')" ]] || {
    echo 'Pods still running; backup aborted to avoid inconsistent runtime data.' >&2; exit 1;
  }
fi
BACKUP_DIR=/root/opencode-backups
mkdir -p "$BACKUP_DIR"
BACKUP="$BACKUP_DIR/runtime-$(date +%Y%m%d-%H%M%S).tar.gz"
FILES=()
for dir in config data secrets dashboard-data prometheus-data grafana-data; do [[ -e "$dir" ]] && FILES+=("$dir"); done
if ((${#FILES[@]})); then
  (umask 077; tar -czf "$BACKUP" "${FILES[@]}")
  tar -tzf "$BACKUP" >/dev/null
  echo "Backup verified: $BACKUP"
fi
if kubectl get ns opencode >/dev/null 2>&1; then
  kubectl delete namespace opencode --wait=true --timeout=180s
fi
if [[ "$MODE" == '--wipe-data' ]]; then
  rm -rf -- "$ROOT/config" "$ROOT/data" "$ROOT/secrets" "$ROOT/dashboard-data" "$ROOT/prometheus-data" "$ROOT/grafana-data"
  echo 'Runtime data removed (backup preserved).'
fi
printf '\nReset completed. Reinstall: bash scripts/install.sh && bash scripts/install-cloudflare.sh\n'
