#!/usr/bin/env bash
# Read-only diagnosis.
set -u
printf '\n== Kubernetes resources ==\n'
kubectl -n opencode get deploy,pods,svc -o wide
printf '\n== Relay service ==\n'
kubectl get svc -A | grep -i hubble-relay || true
printf '\n== Collector logs ==\n'
kubectl -n opencode logs deploy/hubble-collector --tail=30 || true
printf '\n== Dashboard summary ==\n'
NODE_IP="$(kubectl get node master1 -o jsonpath='{.status.addresses[?(@.type=="InternalIP")].address}')"
curl -fsS --max-time 10 "http://${NODE_IP}:31800/api/summary?minutes=5" | python3 -c 'import json,sys; o=json.load(sys.stdin);print("Flow events:",o["metrics"]["total"]);print("Collector:",json.dumps(o.get("collector"),ensure_ascii=False))' || true
printf '\n== Prometheus scrape targets ==\n'
kubectl -n opencode get svc lifecycle-prometheus lifecycle-grafana || true
printf '\nExternal DNS (client): https://dash.innerinfo.org\n'
