#!/usr/bin/env bash
# Monitor upgrade only; OpenCode and cloudflared are untouched.
set -Eeuo pipefail
cd /opt/opencode
for cmd in kubectl docker ctr; do command -v "$cmd" >/dev/null || { echo "Missing: $cmd" >&2; exit 1; }; done
kubectl get node master1 >/dev/null
kubectl -n opencode get secret dashboard-ingest >/dev/null || { echo 'dashboard-ingest secret missing; run scripts/install.sh' >&2; exit 1; }
if ! kubectl -n kube-system get svc hubble-relay >/dev/null 2>&1; then
  echo 'WARNING: kube-system/hubble-relay not found. Update HUBBLE_SERVER in k8s/25-hubble-collector.yaml with actual namespace/port.' >&2
  kubectl get svc -A | grep -i hubble || true
fi
printf '\n[1/3] Building monitoring images\n'
docker build -f Dockerfile.dashboard -t local/https-dashboard:0.4.0 .
docker build -f Dockerfile.collector -t local/hubble-collector:0.4.0 .
docker build -f Dockerfile.grafana -t local/lifecycle-grafana:0.4.0 .
printf '\n[2/3] Loading master1 containerd images\n'
docker save local/https-dashboard:0.4.0 | ctr -n k8s.io images import -
docker save local/hubble-collector:0.4.0 | ctr -n k8s.io images import -
docker save local/lifecycle-grafana:0.4.0 | ctr -n k8s.io images import -
printf '\n[3/3] Applying collector and dashboard (Cloudflare and OpenCode untouched)\n'
install -d -m 0750 -o 10001 -g 10001 /opt/opencode/dashboard-data
install -d -m 0750 -o 65534 -g 65534 /opt/opencode/prometheus-data
install -d -m 0750 -o 472 -g 472 /opt/opencode/grafana-data
if [[ ! -s secrets/grafana_admin_password ]]; then (umask 077; openssl rand -base64 24 > secrets/grafana_admin_password); fi
kubectl -n opencode create secret generic lifecycle-grafana-admin --from-file=password=secrets/grafana_admin_password --dry-run=client -o yaml | kubectl apply -f -
kubectl -n opencode create configmap lifecycle-grafana-dashboards --from-file=dashboard.json=grafana/dashboard.json --dry-run=client -o yaml | kubectl apply -f -
kubectl apply -f k8s/20-dashboard.yaml -f k8s/25-hubble-collector.yaml -f k8s/40-prometheus.yaml -f k8s/50-grafana.yaml
kubectl -n opencode rollout restart deploy/https-dashboard deploy/hubble-collector deploy/lifecycle-prometheus deploy/lifecycle-grafana
kubectl -n opencode rollout status deploy/https-dashboard --timeout=180s
kubectl -n opencode rollout status deploy/hubble-collector --timeout=180s
kubectl -n opencode rollout status deploy/lifecycle-prometheus --timeout=180s
kubectl -n opencode rollout status deploy/lifecycle-grafana --timeout=180s
kubectl -n opencode get deploy,svc,pods -o wide
printf '\nCollector logs (watch): kubectl -n opencode logs -f deploy/hubble-collector\n'
printf 'Dashboard: https://dash.innerinfo.org\n'
