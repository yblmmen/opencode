#!/usr/bin/env bash
# remotely-managed Cloudflare Tunnel (token from user, Kubernetes secret)
set -Eeuo pipefail
set +x
cd /opt/opencode
kubectl apply -f k8s/00-namespace.yaml
ROTATE=false
if [[ "${1:-}" == '--rotate-token' ]]; then ROTATE=true; fi
if [[ "${1:-}" != '' && "${1:-}" != '--rotate-token' ]]; then
  echo "사용법: bash scripts/install-cloudflare.sh [--rotate-token]" >&2; exit 2
fi
if [[ "$ROTATE" == true ]] || ! kubectl -n opencode get secret cloudflared-tunnel >/dev/null 2>&1; then
  read -rs -p 'Cloudflare Tunnel token (eyJ... 문자열만): ' CF_TOKEN; echo
  if [[ "$CF_TOKEN" != eyJ* || ${#CF_TOKEN} -lt 80 || "$CF_TOKEN" =~ [[:space:]] ]]; then
    echo '토큰 형식 확인: Docker 실행 명령 전체가 아닌 eyJ... 토큰만 입력하세요.' >&2
    exit 1
  fi
  printf '%s' "$CF_TOKEN" | kubectl -n opencode create secret generic cloudflared-tunnel \
    --from-file=TUNNEL_TOKEN=/dev/stdin --dry-run=client -o yaml | kubectl apply -f -
  unset CF_TOKEN
else
  echo '기존 Cloudflare Tunnel Secret을 재사용합니다. 변경할 때는 --rotate-token 사용.'
fi
kubectl apply -f k8s/30-cloudflared.yaml
kubectl -n opencode rollout restart deployment/cloudflared
kubectl -n opencode rollout status deployment/cloudflared --timeout=180s
kubectl -n opencode get deployment cloudflared
printf '
Cloudflare Published application 설정:
  Hostname: dash.innerinfo.org
  Service Type: HTTP
  Service URL: http://192.168.9.221:31800
'
