#!/usr/bin/env bash
# Deploy a remotely-managed Cloudflare Tunnel to the existing opencode namespace.
# Does not modify the OpenCode or HTTPS Dashboard deployments.
set -euo pipefail
set +x
ROOT=/opt/opencode
cd "$ROOT"
command -v kubectl >/dev/null || { echo 'ERROR: kubectl is required.' >&2; exit 1; }

kubectl apply -f k8s/00-namespace.yaml
if ! kubectl -n opencode get secret cloudflared-tunnel >/dev/null 2>&1; then
  read -r -s -p 'Cloudflare Tunnel token (eyJ...): ' TUNNEL_TOKEN
  echo
  if [[ -z "${TUNNEL_TOKEN}" ]]; then
    echo 'ERROR: Tunnel token cannot be empty.' >&2
    exit 1
  fi
  # Save only to a Kubernetes Secret, not to a Git-tracked file or shell history.
  printf '%s' "$TUNNEL_TOKEN" |
    kubectl -n opencode create secret generic cloudflared-tunnel \
      --from-file=TUNNEL_TOKEN=/dev/stdin --dry-run=client -o yaml |
    kubectl apply -f -
  unset TUNNEL_TOKEN
else
  echo 'Cloudflare Tunnel Secret already exists; reusing it.'
fi

kubectl apply -f k8s/30-cloudflared.yaml
kubectl -n opencode rollout status deployment/cloudflared --timeout=180s
kubectl -n opencode get deployment cloudflared
printf '\nCloudflare Dashboard: Networking > Tunnels > chosen tunnel > Routes > Published application\n'
printf 'Hostname: dash.innerinfo.org\n'
printf 'Service:  http://https-dashboard.opencode.svc.cluster.local:8080\n'
printf 'Verify:   kubectl -n opencode logs deployment/cloudflared --tail=40\n'
