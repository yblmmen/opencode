# OpenCode + CLI-Anything + Cilium Hubble TCP Lifecycle — v2

**독립적인 v2 완전 신규 설치본**입니다. 과거 v1/v1.1, 임시 패치·업그레이드 파일을 적용하지 않습니다.

## 설치 명령 (master1의 root)

```bash
# ZIP을 먼저 /root/opencode-hubble-v2-final.zip 로 복사
cd /root
unzip -oq opencode-hubble-v2-final.zip -d /root
bash /root/opencode-v2/scripts/reinstall.sh
```

- 위 **reinstall.sh**는 기존 `opencode` 네임스페이스와 `/opt/opencode`를 **백업 후 전체 삭제**하고 v2를 새로 설치합니다.
- 확인 문구 `DELETE OPENCODE V2` 입력 후 실행합니다. Ollama API Key와 Cloudflare Tunnel Token을 새로 입력합니다.
- 기존 설치가 전혀 없다면 `bash /root/opencode-v2/scripts/fresh-install.sh` 사용.
- **초기화만:** `bash /root/opencode-v2/scripts/reset.sh`.
- `/root/opencode-v2` 설치본은 삭제하지 마십시오. 다음 재설치 시 재사용합니다.

## 운영 접속

| 용도 | 접속 주소 / 실행 명령 |
|---|---|
| 외부 Dashboard | https://dash.innerinfo.org |
| 내부 Dashboard | http://192.168.9.221:31800 |
| Grafana NodePort | http://192.168.9.221:31300 |
| Prometheus | ClusterIP 9090 (외부 노출 없음) |
| OpenCode | `kubectl -n opencode exec -it deploy/opencode -- opencode` |
| 수집 상태 점검 | `cd /opt/opencode && bash scripts/check.sh` |
| IP별 TCP 검색 | `bash /opt/opencode/scripts/test-tcp.sh 10.0.0.219` |

**Cloudflare Published Application 설정**: `dash.innerinfo.org` → `http://192.168.9.221:31800` (HTTP Origin). 기존 Cloudflare 외부 라우트/DNS는 그대로 사용합니다.

**제외:** Draw.io 기능 및 자동 PCAP 수집. PCAP 파일을 별도로 제공하면 tshark 기반 HTML 연결 단계 분석 CLI를 사용할 수 있습니다.

**자세한 내용:** [docs/INSTALL_KO.md](docs/INSTALL_KO.md), [docs/architecture.svg](docs/architecture.svg)
