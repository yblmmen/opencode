# OpenCode + CLI-Anything + Cilium Hubble 모니터링 v1 — 초기 설치/초기화 매뉴얼

## A. 확정 구성

| 항목 | 값 |
|---|---|
| Linux / Kubectl 실행 | `master1`, root |
| 프로젝트 디렉터리 | `/opt/opencode` |
| 새 배포 파일을 압축 해제하는 위치 | `/root/opencode-v1` |
| Kubernetes 네임스페이스 | `opencode` |
| OpenCode | `ghcr.io/anomalyco/opencode:2.0.7` 기반 |
| CLI-Anything | 공식 HKUDS GitHub, OpenCode Slash Commands |
| 기존 Hubble Relay | `hubble-relay.kube-system.svc.cluster.local:<실제 Service 포트>` |
| Collector | 자동 연결, 전체 TCP/UDP Flow 기본 수집 |
| Dashboard | `https-dashboard:8080`, NodePort `31800` |
| Cloudflare 터널 | Kubernetes `deploy/cloudflared` |
| 외부 URL | `https://dash.innerinfo.org` |
| Cloudflare Origin | `http://192.168.9.221:31800` |
| Grafana/Prometheus | `lifecycle-grafana:3000`, `lifecycle-prometheus:9090` |
| GitHub 저장소 | `https://github.com/yblmmen/opencode.git`, 브랜치 `main` |

### 구성도

`docs/architecture.svg`를 열어 전체 경로를 확인합니다.

- **실시간 흐름**: Hubble Relay → Hubble Collector → Dashboard(SQLite, `/metrics`) → Prometheus/Grafana Node Graph
- **외부 브라우저**: Cloudflare HTTPS → Cloudflared → master1:31800 → Dashboard Pod:8080
- **개별 TCP/TLS 분석**: 별도 PCAP → tshark → Python CLI → SVG/HTML 수명주기 그래프
- **AI CLI 작업**: OpenCode → CLI-Anything → 기존 프로젝트 소스(`/home/toss`)

Hubble Flow 이벤트는 관측 이벤트이며 TCP 동시 세션 수, TLS 복호화 또는 HTTP URL이 아닙니다. 외부 Cloudflare HTTPS 협상은 Cloudflare Edge에서 끝나므로 NodePort HTTP 패킷으로 복원하지 못합니다.

## B. 설치 전 확인 (최초 1회)

기존 Kubernetes 클러스터, Cilium, Hubble, Cloudflare 터널 리소스가 이미 구성되어 있어야 합니다.

```bash
kubectl get nodes -o wide
kubectl get svc -A | grep -i hubble-relay
kubectl get node master1 -o jsonpath='{.status.nodeInfo.containerRuntimeVersion}{"\n"}'
docker version --format '{{.Server.Version}}'
command -v kubectl docker ctr git openssl curl
```

- `master1` Kubernetes 노드 이름과 containerd 런타임이 필요합니다.
- Docker는 **이미지 빌드 전용**이고 배포는 Kubernetes에서 수행합니다.
- Kubernetes `kube-system/hubble-relay` 서비스가 기본값입니다. 다른 이름 또는 TLS 모드이면 아래 환경변수로 변경 가능합니다.
- Hubble, Cilium 자체는 이번 설치/초기화 스크립트가 변경하지 않습니다.
- Docker 빌드와 클라우드 이미지 다운로드를 위한 네트워크 접근이 필요합니다.

## C. 기존 v2~v4 완전 삭제 + 새 v1 설치 (권장, 단일 명령)

1. 최종 ZIP을 `/root/opencode-hubble-v1.zip`로 복사합니다. **기존 `/opt/opencode` 안에 ZIP을 보관하지 마십시오.**
2. 아래 명령 실행:

```bash
cd /root
unzip -oq /root/opencode-hubble-v1.zip -d /root
bash /root/opencode-v1/scripts/reinstall.sh
```

3. 기존 환경이 있다면 `RESET V1`를 입력합니다. 초기화가 먼저 진행되며 백업 파일은 `/root/opencode-backups/opencode-before-v1-*.tar.gz`에 기록됩니다.
4. 기존 `opencode` 네임스페이스의 **모든 리소스**와 `/opt/opencode`를 삭제합니다. 외부 Cloudflare Route/DNS, GitHub, 기존 Hubble/Cilium 및 `/home/toss`는 그대로 둡니다.
5. 신규 프로젝트를 `/opt/opencode`에 복사하고 Kubernetes v1을 배포합니다.
6. **Ollama API Key**를 입력합니다. OpenCode의 예제 공급자 구성은 `config/opencode.json`에 생성됩니다. 모델 사용 권한은 OpenCode `/models`에서 확인·변경합니다.
7. **Cloudflare Tunnel 토큰**을 입력합니다. Cloudflare 대시보드에 이미 등록된 Route를 재사용합니다.

새 클러스터이거나 기존 배포가 없는 경우에도 같은 절차로 설치 가능합니다.

> 전체 초기화는 기존 세션 데이터, Grafana DB, Prometheus DB를 삭제하므로, 백업 확인 후 실행하세요. 백업은 `/root` 경로에 있으므로 저장공간을 확인하세요. 초기화 도중 네임스페이스가 삭제되면 일시적으로 웹 서비스가 중단됩니다.

### Hubble Relay 주소가 다른 경우

설치 전에 Relay 서비스 위치를 확인한 뒤 해당 값을 지정할 수 있습니다. 예:

```bash
# 스크립트를 분리 실행할 때만 사용 (아래 D절)
HUBBLE_SERVER='hubble-relay.kube-system.svc.cluster.local:80' \
HUBBLE_TLS=false bash /opt/opencode/scripts/install.sh
```

기본값은 `kube-system/hubble-relay` 첫 번째 Service 포트 자동 조회입니다. Relay가 mTLS 인증을 요구하면 인증서 등 별도 설정이 필요합니다.

## D. 초기화와 설치를 분리할 때

```bash
cd /root
unzip -oq /root/opencode-hubble-v1.zip -d /root
bash /root/opencode-v1/scripts/reset.sh
mkdir -p /opt/opencode
cp -a /root/opencode-v1/. /opt/opencode/
cd /opt/opencode
bash scripts/install.sh
bash scripts/install-cloudflare.sh
bash scripts/check.sh
```

## E. 설치 검증 — 반드시 수행

```bash
kubectl -n opencode get pods,deploy,svc -o wide
kubectl -n opencode logs deploy/hubble-collector --tail=60
bash /opt/opencode/scripts/check.sh
```

정상 확인 기준:

- `opencode`, `https-dashboard`, `hubble-collector`, `lifecycle-prometheus`, `lifecycle-grafana`, `cloudflared` Deployment가 READY `1/1`.
- `https-dashboard`는 `NodePort 8080:31800/TCP`.
- Collector 로그에서 `Hubble Relay connected` 확인.
- Dashboard `/api/summary?minutes=5`에서 `collector.state=connected` 확인. **관측 시각과 카운터가 실제 늘어나는지 확인** (트래픽이 없는 구간은 0일 수 있음).
- Prometheus 메트릭 `opencode_hubble_collector_connected 1`.
- 외부 브라우저 `https://dash.innerinfo.org` 접속.
- Grafana Node Graph는 실제 Hubble Flow가 들어와야 연결 노드를 표시.

### 데이터가 0일 때 (리소스가 Running이어도 별도 확인)

```bash
kubectl -n opencode logs deploy/hubble-collector --tail=100
kubectl -n kube-system get svc hubble-relay -o wide
kubectl -n opencode get cm opencode-runtime-settings -o yaml
```

Hubble에서 트래픽이 실제 발생 중인지, Collector의 `observed` 및 `forwarded` 값이 증가하는지 확인하세요. `skipped`가 증가하면 TCP/UDP가 아닌 Flow 또는 IP/포트 정보가 없는 이벤트일 수 있습니다. Dashboard 5분 구간과 Hubble CLI 조회 구간이 같아야 비교할 수 있습니다.

## F. 접속 및 분석 CLI

```bash
# OpenCode
kubectl -n opencode exec -it deploy/opencode -- opencode
# OpenCode 안에서: /cli-anything-list, /https-lifecycle

# Grafana: 서버 터미널에서 실행
kubectl -n opencode port-forward svc/lifecycle-grafana 13000:3000
# server localhost: http://127.0.0.1:13000

# Grafana 관리자 비밀번호
cat /opt/opencode/secrets/grafana_admin_password

# HTML/SVG TCP/TLS lifecycle CLI (PCAP은 실제 파일이어야 합니다)
bash /opt/opencode/scripts/https-lifecycle.sh /home/toss/captures/example.pcapng 0 --out /home/toss/captures/example.html
```

OpenCode가 사용하는 예제 Ollama Cloud 모델은 실제 계정·모델 권한과 다를 수 있습니다. Config 파일의 모델 ID를 계정에서 접근 가능한 값으로 바꾸세요. OpenCode는 인증 설정에 따라 `/connect` 절차가 추가로 필요할 수 있습니다.

### Cloudflare Published application 값

| 항목 | 최종 값 |
|---|---|
| Hostname | `dash.innerinfo.org` |
| Service Type | `HTTP` |
| Origin Service URL | `http://192.168.9.221:31800` |

Cloudflare 외부 접속은 HTTPS, 클러스터 NodePort Origin은 HTTP입니다. 신규 DNS 레코드가 보이지 않으면 사용 PC의 재귀 DNS 캐시를 점검하세요.

## G. GitHub 보관 (선택)

```bash
bash /opt/opencode/scripts/github-push.sh
```

이미 존재하는 `yblmmen/opencode`의 `main` 이력을 보존하려고 Git Clone 기반으로 구성했습니다. `/opt/opencode`의 소스만 기본 게시하고, 세션 데이터와 키까지 게시하려면 `--include-runtime`을 명시해야 합니다. GitHub에서 100MiB 제한 및 비밀정보 탐지 정책에 걸릴 수 있습니다. 토큰을 원격 URL에 직접 입력하지 않습니다.

## H. 초기화/재설치 운영 규칙

**항상 v1을 `/root/opencode-v1`에 보관**하고, 기존 환경 제거가 필요하면:

```bash
cd /root
bash /root/opencode-v1/scripts/reinstall.sh
```

단순 초기화만 할 경우:

```bash
bash /root/opencode-v1/scripts/reset.sh
```

- 삭제 대상은 `namespace/opencode` 전체 + `/opt/opencode` 디렉터리.
- 백업은 `/root/opencode-backups/`.
- `/home/toss` 내용, GitHub 원격 저장소, Cloudflare 외부 Route/DNS, 기존 Cilium/Hubble는 **삭제하지 않음**.
- 명령 중단 후 다시 설치하려면 `D`의 복사 및 설치 절차를 수행합니다.
- 구버전 Docker Compose는 사용하지 않으며, 같은 OpenCode 데이터에 컨테이너와 Pod를 중복 연결하지 않습니다.

## I. 제한 사항

- Hubble Flow는 정책 이벤트 중심의 관측 결과이며, TCP 연결의 모든 패킷이나 정확한 바이트 수를 보장하지 않습니다.
- `Prometheus`는 이벤트 통계이고 `Grafana Node Graph`는 연결 관계를 표현합니다. HTTP URL/키·TLS 암호화 내용을 역추적하지 않습니다.
- 외부 Cloudflare TLS의 실제 3-way handshake 및 TLS 협상은 Edge 구간 PCAP이 필요합니다. Docker/K8s origin HTTP 데이터만으로 복원하지 않습니다.
- `tshark` PCAP CLI는 패킷이 실제로 존재하는 단계만 표시합니다.
- 기존 `master1` 노드 고정 hostPath이므로 운영 클러스터에서 장기적으로 PVC와 레지스트리/HA 설계를 별도로 검토해야 합니다.
- 재설치 매뉴얼은 코드/매니페스트 문법과 단위 테스트 기준이며 실제 클러스터에서 Pod와 Hubble 데이터가 완전히 정상 작동하는지 설치 후 E절로 확인해야 합니다.
