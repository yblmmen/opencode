# OpenCode + CLI-Anything + Hubble Monitoring v1 (CLEAN INSTALL)

**배포 정책: 완전 삭제 후 신규 배포만 지원. v2~v4 업그레이드는 지원하지 않음.**

운영 기준: `master1` / `/opt/opencode` / namespace `opencode` / NodePort **31800** /
Cloudflare `https://dash.innerinfo.org` / GitHub `yblmmen/opencode` main.

## 1. 새 서버 또는 기존 배포판 완전 초기화 후 설치

이 ZIP을 `/root/opencode-hubble-v1.zip`로 전송하고 다음 명령어를 실행합니다.

```bash
cd /root
unzip -oq opencode-hubble-v1.zip -d /root
bash /root/opencode-v1/scripts/reinstall.sh
```

- `RESET V1` 확인을 요구합니다.
- 기존 `/opt/opencode`는 전체 백업 후 삭제하며, `opencode` 네임스페이스는 **전체 삭제**됩니다.
- `/home/toss`, `kube-system`의 Cilium/Hubble, GitHub 저장소, Cloudflare 외부 DNS/Route는 유지합니다.
- 기존 OpenCode Docker 컨테이너가 해당 이미지로 실행 중이면 중지합니다.
- 초기화 백업은 `/root/opencode-backups/`에 보관합니다.
- Ollama Cloud API 키와 Cloudflare Tunnel 토큰을 설치 중 입력합니다(설치 파일에 포함하지 않음).
- Cloudflare Published Route는 `dash.innerinfo.org` → `http://192.168.9.221:31800`으로 유지합니다.

**주의:** `reinstall.sh`는 전체 삭제를 수행합니다. 신규 서버에 이전 배포가 없을 경우에도 사용할 수 있습니다.

## 2. 설치 후 확인

```bash
kubectl -n opencode get pods,svc -o wide
bash /opt/opencode/scripts/check.sh
kubectl -n opencode logs deploy/hubble-collector --tail=60
```

- Dashboard: https://dash.innerinfo.org
- Grafana: `kubectl -n opencode port-forward svc/lifecycle-grafana 13000:3000` → http://127.0.0.1:13000 (원격 PC는 SSH 터널 사용)
- Grafana ID: `admin`, 비밀번호: `/opt/opencode/secrets/grafana_admin_password`
- OpenCode: `kubectl -n opencode exec -it deploy/opencode -- opencode`
- CLI-Anything: OpenCode `/cli-anything-list`
- PCAP 분석: `bash /opt/opencode/scripts/https-lifecycle.sh /path/file.pcapng 0 --out /path/result.html`

Collector가 Relay에 연결되고 Flow 이벤트를 API에 전송해야 실제 카운트가 0을 벗어납니다.
흐름 이벤트 건수는 실제 동시 TLS 세션 수와 다릅니다.

## 3. 초기화만 별도로 수행

```bash
bash /root/opencode-v1/scripts/reset.sh
```

설치 소스(새 ZIP)를 서버 외부 경로에 미리 보관해야 합니다.

## 4. GitHub 소스 반영(선택)

```bash
bash /opt/opencode/scripts/github-push.sh
# (민감정보/운영 데이터까지 포함하려는 경우 명시적으로)
# bash /opt/opencode/scripts/github-push.sh --include-runtime
```

별도의 파일에 GitHub 토큰을 박아 넣지 않으며, Git 인증은 기존 자격증명 도우미 또는 SSH를 이용합니다.

자세한 내용과 제한 사항은 [`docs/INSTALL_KO.md`](docs/INSTALL_KO.md) 참조.
