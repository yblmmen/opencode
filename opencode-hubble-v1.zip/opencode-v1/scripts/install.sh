#!/usr/bin/env bash
# Clean v1 deployment. Run only after reset + copy fresh package.
set -Eeuo pipefail
ROOT=/opt/opencode
cd "$ROOT"
[[ $(id -u) -eq 0 ]] || { echo 'root 권한 필요' >&2; exit 1; }
for bin in kubectl git docker ctr openssl curl; do
  command -v "$bin" >/dev/null || { echo "필수 명령어 없음: $bin" >&2; exit 1; }
done
[[ -f k8s/25-hubble-collector.yaml && -f Dockerfile.collector ]] || { echo 'v1 파일이 /opt/opencode에 없습니다.' >&2; exit 1; }
kubectl get node master1 >/dev/null
RUNTIME=$(kubectl get node master1 -o jsonpath='{.status.nodeInfo.containerRuntimeVersion}')
[[ "$RUNTIME" == containerd* ]] || { echo "master1 containerd 필요; 현재 $RUNTIME" >&2; exit 1; }
[[ ! -d "$ROOT/.git" ]] || echo '참고: Git 작업 디렉터리가 설치 경로에 있습니다.'
# Existing Hubble: no Cilium/Hubble installation/reconfiguration.
if ! kubectl -n kube-system get svc hubble-relay >/dev/null 2>&1; then
  echo 'Hubble Relay 서비스 확인 필요. 설치 전 kubectl get svc -A | grep hubble-relay 로 위치를 확인하십시오.' >&2
  echo '기본 v1은 kube-system/hubble-relay를 가정합니다.' >&2
  exit 1
fi
RELAY_PORT=$(kubectl -n kube-system get svc hubble-relay -o jsonpath='{.spec.ports[0].port}')
HUBBLE_SERVER=${HUBBLE_SERVER:-hubble-relay.kube-system.svc.cluster.local:${RELAY_PORT}}
HUBBLE_TLS=${HUBBLE_TLS:-false}
FILTER_PORTS=${FILTER_PORTS:-}
FILTER_NAMESPACES=${FILTER_NAMESPACES:-}
mkdir -p config/commands data/share data/cache secrets /home/toss
install -d -m 0750 -o 10001 -g 10001 dashboard-data
install -d -m 0750 -o 65534 -g 65534 prometheus-data
install -d -m 0750 -o 472 -g 472 grafana-data
if [[ ! -s secrets/ollama_api_key ]]; then
  read -rs -p 'Ollama API Key (OpenCode용): ' OLLAMA_KEY; echo
  [[ -n "$OLLAMA_KEY" ]] || { echo 'Ollama API Key는 빈 값일 수 없습니다.' >&2; exit 1; }
  (umask 077; printf '%s' "$OLLAMA_KEY" > secrets/ollama_api_key)
  unset OLLAMA_KEY
fi
if [[ ! -s secrets/dashboard_ingest_token ]]; then
  (umask 077; openssl rand -hex 32 > secrets/dashboard_ingest_token)
fi
if [[ ! -s secrets/grafana_admin_password ]]; then
  (umask 077; openssl rand -base64 24 > secrets/grafana_admin_password)
fi
chmod 600 secrets/*
if [[ ! -s config/opencode.json ]]; then
  cp examples/opencode.sample.json config/opencode.json
fi
if [[ ! -f CLI-Anything/cli-anything-plugin/HARNESS.md ]]; then
  git clone --depth 1 https://github.com/HKUDS/CLI-Anything.git CLI-Anything
fi
shopt -s nullglob
COMMANDS=(CLI-Anything/opencode-commands/*.md)
((${#COMMANDS[@]})) || { echo 'CLI-Anything 명령 파일이 없습니다.' >&2; exit 1; }
cp "${COMMANDS[@]}" config/commands/
cp CLI-Anything/cli-anything-plugin/HARNESS.md config/commands/
sed -i 's#\./HARNESS\.md#/root/.config/opencode/commands/HARNESS.md#g' config/commands/cli-anything*.md
cat > config/commands/https-lifecycle.md <<'CMD'
---
description: Analyze observed HTTPS TCP/TLS lifecycle from PCAP with tshark
---
Use /workspace/opencode-project/scripts/https-lifecycle.sh to analyze the PCAP given by the user.
Do not invent unobserved TCP/TLS phases. The packet capture MUST include those stages.
Request: $ARGUMENTS
CMD
echo '[1/5] v1 images build'
docker build -f Dockerfile -t local/opencode:v1 .
docker build -f Dockerfile.dashboard -t local/https-dashboard:v1 .
docker build -f Dockerfile.collector -t local/hubble-collector:v1 .
docker build -f Dockerfile.grafana -t local/lifecycle-grafana:v1 .
echo '[2/5] master1 containerd image import'
for img in local/opencode:v1 local/https-dashboard:v1 local/hubble-collector:v1 local/lifecycle-grafana:v1; do
  docker save "$img" | ctr -n k8s.io images import -
done
echo '[3/5] namespace / configuration / secrets'
kubectl apply -f k8s/00-namespace.yaml
kubectl -n opencode create secret generic ollama-api-key --from-file=OLLAMA_API_KEY=secrets/ollama_api_key --dry-run=client -o yaml | kubectl apply -f -
kubectl -n opencode create secret generic dashboard-ingest --from-file=token=secrets/dashboard_ingest_token --dry-run=client -o yaml | kubectl apply -f -
kubectl -n opencode create secret generic lifecycle-grafana-admin --from-file=password=secrets/grafana_admin_password --dry-run=client -o yaml | kubectl apply -f -
kubectl -n opencode create configmap opencode-runtime-settings \
  --from-literal=HUBBLE_SERVER="$HUBBLE_SERVER" \
  --from-literal=HUBBLE_TLS="$HUBBLE_TLS" \
  --from-literal=FILTER_PORTS="$FILTER_PORTS" \
  --from-literal=FILTER_NAMESPACES="$FILTER_NAMESPACES" \
  --dry-run=client -o yaml | kubectl apply -f -
kubectl -n opencode create configmap lifecycle-grafana-dashboards --from-file=dashboard.json=grafana/dashboard.json --dry-run=client -o yaml | kubectl apply -f -
echo '[4/5] Deploy OpenCode / Dashboard / Collector / Prometheus / Grafana'
for y in 10-opencode.yaml 20-dashboard.yaml 25-hubble-collector.yaml 40-prometheus.yaml 50-grafana.yaml; do
  kubectl apply -f "k8s/$y"
done
for name in opencode https-dashboard hubble-collector lifecycle-prometheus lifecycle-grafana; do
  kubectl -n opencode rollout status "deploy/$name" --timeout=240s
done
echo '[5/5] Finished. Cloudflare Tunnel separately: bash scripts/install-cloudflare.sh'
kubectl -n opencode get pods,svc -o wide
printf '\nHubble relay: %s (TLS=%s)\n' "$HUBBLE_SERVER" "$HUBBLE_TLS"
printf 'OpenCode: kubectl -n opencode exec -it deploy/opencode -- opencode\n'
printf 'Grafana: kubectl -n opencode port-forward svc/lifecycle-grafana 13000:3000\n'
printf 'Verify: bash scripts/check.sh\n'
